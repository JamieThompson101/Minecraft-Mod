package net.troglodyte.thiccmod.client.renderer;

import net.minecraft.client.renderer.entity.EntityRenderers;

public class ModRenderer {
}
