package net.troglodyte.thiccmod.networking.packet;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.network.NetworkEvent;
import net.troglodyte.thiccmod.client.ClientBloodPressureData;

import java.util.function.Supplier;

public class DementiaDataSyncS2CPacket {
    private final int dementia;

    public DementiaDataSyncS2CPacket(int bp) {
        this.dementia = bp;
    }

    public DementiaDataSyncS2CPacket(FriendlyByteBuf buf) {
        this.dementia = buf.readInt();
    }

    public void toBytes(FriendlyByteBuf buf) {
        buf.writeInt(dementia);
    }

    public boolean handle(Supplier<NetworkEvent.Context> supplier) {
        NetworkEvent.Context context = supplier.get();
        context.enqueueWork(() -> {
            // HERE WE ARE ON THE CLIENT!
            ClientBloodPressureData.set(dementia);
        });
        return true;
    }
}
