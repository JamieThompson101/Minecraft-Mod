package net.troglodyte.thiccmod.client;

public class ClientScaleData {
    private static float playerScale;

    public static void set(float scale) {
        ClientScaleData.playerScale= scale;
    }

    public static float getPlayerScale() {
        return playerScale;
    }
}
