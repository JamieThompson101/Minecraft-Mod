package net.troglodyte.thiccmod.block;

import com.google.common.base.Supplier;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;
import net.troglodyte.thiccmod.ThiccMod;
import net.troglodyte.thiccmod.block.custom.*;
import net.troglodyte.thiccmod.item.ModItems;
import net.troglodyte.thiccmod.sound.ModSounds;

public class ModBlocks {
    public static final DeferredRegister<Block> BLOCKS =
            DeferredRegister.create(ForgeRegistries.BLOCKS, ThiccMod.MODID);
    public static final RegistryObject<Block> REDDIT_COMPUTER = registerBlock("reddit_computer",
            () -> new ModRedditComputerBlock(BlockBehaviour.Properties.copy(Blocks.IRON_BLOCK).sound(ModSounds.COMPUTER_BLOCK_SOUNDS).strength(1f).noOcclusion()));

    public static final RegistryObject<Block> HELEN_KELLER_BLOCK = registerBlock("helen_keller_block",
            () -> new HelenKellerBlock(BlockBehaviour.Properties.copy(Blocks.DIRT).noOcclusion()));

    public static final RegistryObject<Block> CASE_OF_BUSCH_LIGHT = registerBlock("case_of_busch_light_block",
            () -> new CaseOfBuschLightBlock(BlockBehaviour.Properties.copy(Blocks.COPPER_BLOCK).noOcclusion()));

    public static final RegistryObject<Block> CASE_OF_PBR_BLOCK = registerBlock("case_of_pbr_block",
            () -> new CaseOfPbrBlock(BlockBehaviour.Properties.copy(Blocks.COPPER_BLOCK).noOcclusion()));

    public static final RegistryObject<Block> CASE_OF_WINE_BLOCK = registerBlock("case_of_wine_block",
            () -> new CaseOfWineBlock(BlockBehaviour.Properties.copy(Blocks.GLASS).noOcclusion()));

    private static <T extends Block> RegistryObject<T> registerBlock(String name, Supplier<T> block) {
        RegistryObject<T> toReturn = BLOCKS.register(name, block);
        registerBlockItem(name, toReturn);
        return toReturn;
    }
    private static <T extends Block> RegistryObject<Item> registerBlockItem(String name, RegistryObject<T> block) {
        return ModItems.ITEMS.register(name, () -> new BlockItem(block.get(), new Item.Properties()));
    }
    public static void register(IEventBus eventBus) {

        BLOCKS.register(eventBus);
    }
}
