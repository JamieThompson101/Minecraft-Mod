package net.troglodyte.thiccmod.bloodpressure;

import net.minecraft.nbt.CompoundTag;

public class PlayerBloodPressure {
    private int bloodPressure;
    private final int MIN_BLOOD_PRESSURE = 0;
    private final int MAX_BLOOD_PRESSURE = 20;

    public int getBloodPressure() {
        return bloodPressure;
    }

    public void addBloodPressure(int add) {
        this.bloodPressure = Math.min(bloodPressure + add, MAX_BLOOD_PRESSURE);
    }

    public void subBloodPressure(int sub) {
        this.bloodPressure = Math.max(bloodPressure - sub, MIN_BLOOD_PRESSURE);
    }

    public void copyFrom(PlayerBloodPressure source) {
        this.bloodPressure = source.bloodPressure;
    }

    public void saveNBTData(CompoundTag nbt) {
        nbt.putInt("bloodpressure", bloodPressure);
    }

    public void loadNBTData(CompoundTag nbt) {
        bloodPressure = nbt.getInt("bloodpressure");
    }
}
