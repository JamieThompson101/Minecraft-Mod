package net.troglodyte.thiccmod.block.custom;

import it.unimi.dsi.fastutil.objects.Object2ByteLinkedOpenHashMap;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.CactusBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.SculkCatalystBlockEntity;
import net.minecraft.world.level.block.MagmaBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.shapes.BooleanOp;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;
import net.troglodyte.thiccmod.block.entity.HelenKellerBlockEntity;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class HelenKellerBlock extends BaseEntityBlock {

    private Boolean isTouched;
    private BlockEntity entity;
    public HelenKellerBlock(Properties pProperties) {
        super(pProperties);
        isTouched = false;
    }

    @Override
    public @NotNull RenderShape getRenderShape(BlockState pState) {
        if(isTouched){
            return RenderShape.MODEL;
        }
        return RenderShape.INVISIBLE;
    }

    @Nullable
    @Override
    public BlockEntity newBlockEntity(BlockPos blockPos, BlockState blockState) {
        return new HelenKellerBlockEntity(blockPos, blockState);
    }

    @Override
    public void entityInside(BlockState pState, Level pLevel, BlockPos pPos, Entity pEntity){
        isTouched = true;
        //pEntity.hurt(pLevel.damageSources().cactus(), 1.0F);
    }


    @Override
    public float getShadeBrightness(BlockState pState, BlockGetter pLevel, BlockPos pPos){
        if(isTouched){
            return 1.0f;
        }
        return 0.0f;
    }


    @Override
    public void stepOn(Level pLevel, BlockPos pPos, BlockState pState, Entity pEntity){
        isTouched = true;
        super.stepOn(pLevel, pPos, pState, pEntity);
    }

}
