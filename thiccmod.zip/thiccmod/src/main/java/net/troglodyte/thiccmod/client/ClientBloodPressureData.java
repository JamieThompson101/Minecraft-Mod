package net.troglodyte.thiccmod.client;

public class ClientBloodPressureData {
    private static int playerBloodPressure;

    public static void set(int bloodPressure) {
        ClientBloodPressureData.playerBloodPressure = bloodPressure;
    }

    public static int getPlayerBloodPressure() {
        return playerBloodPressure;
    }
}
