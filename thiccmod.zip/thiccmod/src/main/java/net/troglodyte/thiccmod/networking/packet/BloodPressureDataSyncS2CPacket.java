package net.troglodyte.thiccmod.networking.packet;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.network.NetworkEvent;
import net.troglodyte.thiccmod.client.ClientBloodPressureData;

import java.util.function.Supplier;

public class BloodPressureDataSyncS2CPacket {
    private final int bloodPressure;

    public BloodPressureDataSyncS2CPacket(int bp) {
        this.bloodPressure = bp;
    }

    public BloodPressureDataSyncS2CPacket(FriendlyByteBuf buf) {
        this.bloodPressure = buf.readInt();
    }

    public void toBytes(FriendlyByteBuf buf) {

        buf.writeInt(bloodPressure);
    }

    public boolean handle(Supplier<NetworkEvent.Context> supplier) {
        NetworkEvent.Context context = supplier.get();
        context.enqueueWork(() -> {
            // HERE WE ARE ON THE CLIENT!
            ClientBloodPressureData.set(bloodPressure);
        });
        return true;
    }
}
