package net.troglodyte.thiccmod.entity.client;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;
import net.troglodyte.thiccmod.ThiccMod;
import net.troglodyte.thiccmod.entity.custom.ScooterEntity;
import net.troglodyte.thiccmod.entity.custom.TruckEntity;

public class TruckRenderer extends MobRenderer<TruckEntity, TruckModel<TruckEntity>> {
    public TruckRenderer(EntityRendererProvider.Context pContext) {
        super(pContext, new TruckModel<>(pContext.bakeLayer(ModModelLayers.TRUCK_LAYER)), 1.2f);
    }

    @Override
    public ResourceLocation getTextureLocation(TruckEntity pEntity) {
        return new ResourceLocation(ThiccMod.MODID,"textures/mob/truck.png");
    }

    @Override
    public void render(TruckEntity pEntity, float pEntityYaw, float pPartialTicks, PoseStack pMatrixStack, MultiBufferSource pBuffer, int pPackedLight) {
        if(pEntity.isBaby()){
            pMatrixStack.scale(.5f, .5f, .5f);
        }

        super.render(pEntity, pEntityYaw, pPartialTicks, pMatrixStack, pBuffer, pPackedLight);
    }
}
