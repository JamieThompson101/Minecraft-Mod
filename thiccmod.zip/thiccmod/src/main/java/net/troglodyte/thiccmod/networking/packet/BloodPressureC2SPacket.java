package net.troglodyte.thiccmod.networking.packet;

import net.minecraft.ChatFormatting;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.level.block.Blocks;
import net.minecraftforge.network.NetworkEvent;
import net.troglodyte.thiccmod.bloodpressure.PlayerBloodPressureProvider;
import net.troglodyte.thiccmod.client.ClientBloodPressureData;
import net.troglodyte.thiccmod.networking.ModMessages;

import java.util.function.Supplier;

public class BloodPressureC2SPacket {
    private static final String MESSAGE_LOWER_BLOOD_PRESSURE = "message.thiccmod.lowerbloodpressure";
    private static final String MESSAGE_TOO_LATE_TO_LOWER_BLOOD_PRESSURE = "message.thiccmod.toolate";

    public BloodPressureC2SPacket() {

    }

    public BloodPressureC2SPacket(FriendlyByteBuf buf) {

    }

    public void toBytes(FriendlyByteBuf buf) {

    }

    public boolean handle(Supplier<NetworkEvent.Context> supplier) {
        NetworkEvent.Context context = supplier.get();
        context.enqueueWork(() -> {
            // HERE WE ARE ON THE SERVER!
            ServerPlayer player = context.getSender();
            ServerLevel level = player.serverLevel();
            player.getCapability(PlayerBloodPressureProvider.PLAYER_BLOOD_PRESSURE).ifPresent(bloodPressure -> {
                    player.sendSystemMessage(Component.literal("Current BloodPressure " + bloodPressure.getBloodPressure())
                            .withStyle(ChatFormatting.RED));
                    ModMessages.sendToPlayer(new BloodPressureDataSyncS2CPacket(bloodPressure.getBloodPressure()), player);
                    ClientBloodPressureData.set(bloodPressure.getBloodPressure());
            });


        });
        return true;
    }

    private boolean isSprinting(ServerPlayer player, ServerLevel level, int size) {

        return player.isSprinting();
    }
}
