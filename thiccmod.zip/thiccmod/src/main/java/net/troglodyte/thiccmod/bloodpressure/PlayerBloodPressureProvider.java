package net.troglodyte.thiccmod.bloodpressure;

import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.common.capabilities.CapabilityManager;
import net.minecraftforge.common.capabilities.CapabilityToken;
import net.minecraftforge.common.capabilities.ICapabilityProvider;
import net.minecraftforge.common.util.LazyOptional;
import net.minecraftforge.common.util.INBTSerializable;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class PlayerBloodPressureProvider implements ICapabilityProvider, INBTSerializable<CompoundTag> {
    public static Capability<PlayerBloodPressure> PLAYER_BLOOD_PRESSURE = CapabilityManager.get(new CapabilityToken<PlayerBloodPressure>() { });

    private PlayerBloodPressure bloodPressure = null;
    private final LazyOptional<PlayerBloodPressure> optional = LazyOptional.of(this::createPlayerBloodPressure);

    private PlayerBloodPressure createPlayerBloodPressure() {
        if(this.bloodPressure == null) {
            this.bloodPressure = new PlayerBloodPressure();
        }

        return this.bloodPressure;
    }

    @Override
    public @NotNull <T> LazyOptional<T> getCapability(@NotNull Capability<T> cap, @Nullable Direction side) {
        if(cap == PLAYER_BLOOD_PRESSURE) {
            return optional.cast();
        }

        return LazyOptional.empty();
    }

    @Override
    public CompoundTag serializeNBT() {
        CompoundTag nbt = new CompoundTag();
        createPlayerBloodPressure().saveNBTData(nbt);
        return nbt;
    }

    @Override
    public void deserializeNBT(CompoundTag nbt) {
        createPlayerBloodPressure().loadNBTData(nbt);
    }
}
