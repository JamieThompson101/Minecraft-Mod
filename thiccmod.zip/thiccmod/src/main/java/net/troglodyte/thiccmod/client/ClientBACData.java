package net.troglodyte.thiccmod.client;

public class ClientBACData {

    private static int playerBAC;

    public static void set(int bac) {
        ClientBACData.playerBAC= bac;
    }

    public static int getPlayerBAC() {
        return playerBAC;
    }
}
