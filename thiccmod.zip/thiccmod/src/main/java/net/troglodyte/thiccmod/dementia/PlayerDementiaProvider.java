package net.troglodyte.thiccmod.dementia;
import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.common.capabilities.CapabilityManager;
import net.minecraftforge.common.capabilities.CapabilityToken;
import net.minecraftforge.common.capabilities.ICapabilityProvider;
import net.minecraftforge.common.util.LazyOptional;
import net.minecraftforge.common.util.INBTSerializable;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class PlayerDementiaProvider implements ICapabilityProvider, INBTSerializable<CompoundTag> {
    public static Capability<PlayerDementia> PLAYER_DEMENTIA = CapabilityManager.get(new CapabilityToken<PlayerDementia>() { });

    private PlayerDementia dementia = null;
    private final LazyOptional<PlayerDementia> optional = LazyOptional.of(this::createPlayerDementia);

    private PlayerDementia createPlayerDementia() {
        if(this.dementia == null) {
            this.dementia = new PlayerDementia();
        }

        return this.dementia;
    }

    @Override
    public @NotNull <T> LazyOptional<T> getCapability(@NotNull Capability<T> cap, @Nullable Direction side) {
        if(cap == PLAYER_DEMENTIA) {
            return optional.cast();
        }

        return LazyOptional.empty();
    }

    @Override
    public CompoundTag serializeNBT() {
        CompoundTag nbt = new CompoundTag();
        createPlayerDementia().saveNBTData(nbt);
        return nbt;
    }

    @Override
    public void deserializeNBT(CompoundTag nbt) {
        createPlayerDementia().loadNBTData(nbt);
    }
}