package net.troglodyte.thiccmod.item.custom;

import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;
import net.troglodyte.thiccmod.block.ModBlocks;
import net.troglodyte.thiccmod.item.ModItems;
import net.troglodyte.thiccmod.ThiccMod;

public class ModCreativeModeTabs {
    public static final DeferredRegister<CreativeModeTab> CREATIVE_MODE_TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, ThiccMod.MODID);

    public static final RegistryObject<CreativeModeTab> TUTORIAL_TAB = CREATIVE_MODE_TABS.register("tutorial_tab",
            () -> CreativeModeTab.builder().icon(() -> new ItemStack(ModItems.MOUNTAINDEW.get()))
                    .title(Component.translatable("creativetab.tutorial_tab"))
                    .displayItems((pParameters, pOutput) -> {

                        pOutput.accept(ModItems.MOUNTAINDEW.get());
                        pOutput.accept(ModItems.DORITOS.get());
                        pOutput.accept(ModItems.WAFFLE.get());
                        pOutput.accept(ModItems.FRIES.get());
                        pOutput.accept(ModItems.BIGMAC.get());
                        pOutput.accept(ModItems.ARBYSROASTBEEF.get());
                        pOutput.accept(ModItems.BBQSAUCE.get());
                        pOutput.accept(ModItems.CHICKENSANDWICH.get());
                        pOutput.accept(ModItems.SPICYRAMEN.get());
                        pOutput.accept(ModItems.SPICYTAKIS.get());
                        pOutput.accept(ModItems.NUGGIES.get());
                        pOutput.accept(ModItems.BBQSAUCE.get());
                        pOutput.accept(ModItems.BUSCH_LITE.get());
                        pOutput.accept(ModItems.WINE.get());
                        pOutput.accept(ModItems.NATTY_DADDY.get());
                        pOutput.accept(ModItems.BOURBON.get());
                        pOutput.accept(ModItems.MOONSHINE.get());
                        pOutput.accept(ModItems.PBR.get());
                        pOutput.accept(ModItems.SCOTCH.get());
                        pOutput.accept(ModItems.FOURLOKO.get());

                        pOutput.accept(ModItems.DISCORD_KITTEN_SPAWN_EGG.get());
                        pOutput.accept(ModItems.SCOOTER_SPAWN_EGG.get());
                        pOutput.accept(ModItems.DISCORD_NITRO.get());

                        pOutput.accept(ModBlocks.REDDIT_COMPUTER.get());

                        pOutput.accept(ModBlocks.HELEN_KELLER_BLOCK.get());
                        pOutput.accept(ModBlocks.CASE_OF_BUSCH_LIGHT.get());
                        pOutput.accept(ModBlocks.CASE_OF_PBR_BLOCK.get());
                        pOutput.accept(ModBlocks.CASE_OF_WINE_BLOCK.get());
                        pOutput.accept(ModItems.TRUCK_SPAWN_EGG.get());

                    })
                    .build());


    public static void register(IEventBus eventBus) {
        CREATIVE_MODE_TABS.register(eventBus);
    }
}
