package net.troglodyte.thiccmod;

import com.mojang.logging.LogUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.MenuScreens;
import net.minecraft.client.renderer.entity.EntityRenderers;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.event.server.ServerStartingEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.troglodyte.thiccmod.block.ModBlocks;
import net.troglodyte.thiccmod.block.entity.ModBlockEntities;
import net.troglodyte.thiccmod.entity.ModEntities;
import net.troglodyte.thiccmod.item.ModItems;
import net.troglodyte.thiccmod.loot.ModLootModifiers;
import net.troglodyte.thiccmod.networking.ModMessages;
import net.troglodyte.thiccmod.screen.ModMenuTypes;
import net.troglodyte.thiccmod.screen.ModRedditComputerScreen;
import net.troglodyte.thiccmod.sound.ModSounds;
import net.troglodyte.thiccmod.villager.ModVillagers;
import net.troglodyte.thiccmod.worldgen.biome.ModTerraBlender;
import net.troglodyte.thiccmod.worldgen.biome.surface.ModSurfaceRules;
import net.troglodyte.thiccmod.entity.client.DiscordKittenRenderer;
import net.troglodyte.thiccmod.entity.client.ScooterRenderer;
import net.troglodyte.thiccmod.entity.client.TruckRenderer;
import net.troglodyte.thiccmod.item.custom.ModCreativeModeTabs;
import org.slf4j.Logger;
import terrablender.api.SurfaceRuleManager;

// The value here should match an entry in the META-INF/mods.toml file
@Mod(ThiccMod.MODID)
public class ThiccMod
{
    // Define mod id in a common place for everything to reference
    public static final String MODID = "thiccmod";
    // Directly reference a slf4j logger
    private static final Logger LOGGER = LogUtils.getLogger();




    public ThiccMod()
    {
        IEventBus modEventBus = FMLJavaModLoadingContext.get().getModEventBus();

        //register all me mods
        ModItems.register(modEventBus);
        ModBlocks.register(modEventBus);
        ModLootModifiers.register(modEventBus);
        ModBlockEntities.register(modEventBus);
        ModCreativeModeTabs.register(modEventBus);
        ModMenuTypes.register(modEventBus);
        ModSounds.register(modEventBus);
        ModVillagers.register(modEventBus);
        ModTerraBlender.registerBiomes();
        ModEntities.register(modEventBus);
        // Register the commonSetup method for modloading
        modEventBus.addListener(this::commonSetup);


        // Register ourselves for server and other game events we are interested in
        MinecraftForge.EVENT_BUS.register(this);

        // Register the item to a creative tab
        modEventBus.addListener(this::addCreative);

        // Register our mod's ForgeConfigSpec so that Forge can create and load the config file for us
        ModLoadingContext.get().registerConfig(ModConfig.Type.COMMON, Config.SPEC);
    }

    private void commonSetup(final FMLCommonSetupEvent event) {
        event.enqueueWork(() -> {
            LOGGER.info("Hello from addSurfaceRules");
            SurfaceRuleManager.addSurfaceRules(SurfaceRuleManager.RuleCategory.OVERWORLD, MODID, ModSurfaceRules.makeRules());
        });
        ModMessages.register();
    }

    // Add the example block item to the building blocks tab
    private void addCreative(BuildCreativeModeTabContentsEvent event) {
        if(event.getTabKey() == CreativeModeTabs.FOOD_AND_DRINKS){
            event.accept(ModItems.DORITOS);
            event.accept(ModItems.BORGAR);
            event.accept(ModItems.MOUNTAINDEW);
            event.accept(ModItems.ANTIDEPRESSANT);
            event.accept(ModItems.POOP);
            event.accept(ModItems.FRIES);
            event.accept(ModItems.BIGMAC);
            event.accept(ModItems.ARBYSROASTBEEF);
            event.accept(ModItems.NUGGIES);
            event.accept(ModItems.BBQSAUCE);
            event.accept(ModItems.CHICKENSANDWICH);
            event.accept(ModItems.SPICYRAMEN);
            event.accept(ModItems.SPICYTAKIS);
            event.accept(ModItems.BUSCH_LITE);
            event.accept(ModItems.BOURBON);
            event.accept(ModItems.WINE);
            event.accept(ModItems.FOURLOKO);
        }
    }

    // You can use SubscribeEvent and let the Event Bus discover methods to call
    @SubscribeEvent
    public void onServerStarting(ServerStartingEvent event)
    {
        // Do something when the server starts
        LOGGER.info("HELLO from server starting");
    }

    // You can use EventBusSubscriber to automatically register all static methods in the class annotated with @SubscribeEvent
    @Mod.EventBusSubscriber(modid = MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
    public static class ClientModEvents
    {
        @SubscribeEvent
        public static void onClientSetup(FMLClientSetupEvent event)
        {
            EntityRenderers.register(ModEntities.DISCORD_KITTEN.get(), DiscordKittenRenderer::new);
            EntityRenderers.register(ModEntities.SCOOTER.get(), ScooterRenderer::new);
            EntityRenderers.register(ModEntities.TRUCK.get(), TruckRenderer::new);
            MenuScreens.register(ModMenuTypes.REDDIT_COMPUTER_MENU.get(), ModRedditComputerScreen::new);
        }
    }
}
