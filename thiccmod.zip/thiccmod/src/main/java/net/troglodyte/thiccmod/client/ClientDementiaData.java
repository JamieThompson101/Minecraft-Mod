package net.troglodyte.thiccmod.client;

public class ClientDementiaData {

    private static int playerDementia;

    public static void set(int dementia) {
        ClientDementiaData.playerDementia = dementia;
    }

    public static int getPlayerDementia() {
        return playerDementia;
    }
}
