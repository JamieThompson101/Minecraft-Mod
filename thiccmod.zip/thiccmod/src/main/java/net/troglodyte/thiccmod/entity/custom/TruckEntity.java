package net.troglodyte.thiccmod.entity.custom;

import net.minecraft.core.BlockPos;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.Mth;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageSources;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.entity.animal.horse.AbstractHorse;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;

import java.util.Iterator;

public class TruckEntity extends AbstractHorse {

    private float standAnimO = 1f;
    public TruckEntity(EntityType<? extends AbstractHorse> pEntityType, Level pLevel) {
        super(pEntityType, pLevel);
    }
    @Override
    protected void registerGoals(){
        //this, like many sad souls in this world, has no goals(it shouldn't move at all)
    }

    @Override
    protected void addBehaviourGoals() {
        //can't even add goals
    }

    @Override
    public boolean isTamed() {
        return true;
    }

    @Override
    public boolean isSaddleable() {
        return false;
    }
    @Override
    public boolean isSaddled() {
        return true;
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Animal.createLivingAttributes()
                .add(Attributes.MAX_HEALTH, 20D)
                .add(Attributes.MOVEMENT_SPEED, 1D)
                .add(Attributes.FOLLOW_RANGE, 28D)
                .add(Attributes.ATTACK_DAMAGE, 2D)
                .add(Attributes.ATTACK_KNOCKBACK, .5D)
                .add(Attributes.ATTACK_SPEED, 1D);
    }

    @Override
    protected void executeRidersJump(float p_248808_, Vec3 p_275435_){
        //do nothing, the scooter cannot jump
    }

    @Override
    protected void positionRider(Entity pPassenger, Entity.MoveFunction pCallback) {
        super.positionRider(pPassenger, pCallback);
        if (this.standAnimO > 0.0F) {
            float f = Mth.sin(this.yBodyRot * 0.017453292F);
            float f1 = Mth.cos(this.yBodyRot * 0.017453292F);
            float f2 = 0.7F * this.standAnimO;
            float f3 = 0.15F * this.standAnimO;
            pCallback.accept(pPassenger, this.getX() + (double)(f2 * f), this.getY() + .55f + pPassenger.getMyRidingOffset() + (double)f3, this.getZ() - (double)(f2 * f1));
            if (pPassenger instanceof LivingEntity) {
                ((LivingEntity)pPassenger).yBodyRot = this.yBodyRot;
            }
        }

    }

    @Override
    protected float getRiddenSpeed(Player pPlayer) {
        return .3f;
    }


    @Override
    protected void playStepSound(BlockPos pPos, BlockState pBlock) {
        this.playSound(SoundEvents.STONE_STEP, .1f, 1f);
    }

    @Override
    protected void playGallopSound(SoundType pSoundType) {
        this.playSound(SoundEvents.STONE_STEP, 0.2f, 1f);
    }

    @Override
    protected void playJumpSound() {
        //no jumpin
    }

    @Override
    public void tick(){
        //explode if hp is low
        if(this.getHealth() < 5){
            this.level().explode(this, this.getX(), this.getY(), this.getZ(), 5f, Level.ExplosionInteraction.MOB);
        }
        super.tick();
    }

    @Override
    public boolean causeFallDamage(float pFallDistance, float pMultiplier, DamageSource pSource) {
        if (pFallDistance > 1.0F) {
            this.playSound(SoundEvents.STONE_BREAK, 0.4F, 1.0F);
        }

        int i = this.calculateFallDamage(pFallDistance, pMultiplier);
        if (i <= 0) {
            return false;
        } else {
            this.hurt(pSource, (float)i);
            if (this.isVehicle()) {
                Iterator var5 = this.getIndirectPassengers().iterator();

                while(var5.hasNext()) {
                    Entity entity = (Entity)var5.next();
                    entity.hurt(pSource, (float)i);
                }
            }

            this.playBlockFallSound();
            return true;
        }
    }

}
