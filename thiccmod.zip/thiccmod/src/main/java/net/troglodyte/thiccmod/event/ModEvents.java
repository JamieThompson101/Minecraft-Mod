package net.troglodyte.thiccmod.event;

import com.mojang.authlib.minecraft.client.MinecraftClient;
import com.mojang.logging.LogUtils;
import it.unimi.dsi.fastutil.ints.Int2ObjectMap;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Holder;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.Mth;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageType;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MobType;
import net.minecraft.world.entity.npc.VillagerProfession;
import net.minecraft.world.entity.npc.VillagerTrades;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.food.FoodData;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.trading.MerchantOffer;
import net.minecraft.world.level.ItemLike;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.WorldDataConfiguration;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.lighting.LevelLightEngine;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.common.ForgeConfig;
import net.minecraftforge.common.ticket.AABBTicket;
import net.minecraftforge.event.AttachCapabilitiesEvent;
import net.minecraftforge.event.CommandEvent;
import net.minecraftforge.event.entity.EntityJoinLevelEvent;
import net.minecraftforge.event.entity.player.PlayerSleepInBedEvent;
import net.minecraftforge.event.entity.player.SleepingTimeCheckEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.living.LivingEntityUseItemEvent;
import net.minecraftforge.event.entity.living.LivingEntityUseItemEvent.Finish;
import net.minecraftforge.event.level.SleepFinishedTimeEvent;
import net.minecraftforge.event.village.VillagerTradesEvent;
import net.minecraftforge.fml.LogicalSide;
import net.troglodyte.thiccmod.bac.PlayerBAC;
import net.troglodyte.thiccmod.bac.PlayerBACProvider;
import net.troglodyte.thiccmod.block.ModBlocks;
import net.troglodyte.thiccmod.bloodpressure.PlayerBloodPressureProvider;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.common.capabilities.RegisterCapabilitiesEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.TickEvent;
import net.troglodyte.thiccmod.ThiccMod;
import net.minecraft.world.entity.Entity;
import net.troglodyte.thiccmod.bloodpressure.PlayerBloodPressure;
import net.troglodyte.thiccmod.dementia.PlayerDementia;
import net.troglodyte.thiccmod.dementia.PlayerDementiaProvider;
import net.troglodyte.thiccmod.item.ModItems;
import net.troglodyte.thiccmod.networking.ModMessages;
import net.troglodyte.thiccmod.networking.packet.BACDataSyncS2CPacket;
import net.troglodyte.thiccmod.networking.packet.BloodPressureDataSyncS2CPacket;
import net.minecraft.sounds.SoundEvent;
import net.troglodyte.thiccmod.networking.packet.ScaleDataSyncS2CPacket;
import net.troglodyte.thiccmod.scale.PlayerScale;
import net.troglodyte.thiccmod.scale.PlayerScaleProvider;
import net.troglodyte.thiccmod.sound.ModSounds;
import net.troglodyte.thiccmod.villager.ModVillagers;
import org.slf4j.Logger;
//import virtuoel.pehkui.api.ScaleData;
//import virtuoel.pehkui.api.ScaleTypes;
//import virtuoel.pehkui.util.PehkuiEntityExtensions;


import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Stream;


@Mod.EventBusSubscriber(modid = ThiccMod.MODID)
public class ModEvents {

    private static float scale = 1f;

    private static int drunk_counter = 0;
    private static int bloodAlcoholContent = 0;
    private static double oldX = 0D;
    private static double oldZ = 0D;

    private static int boomCounter = 1500;

    //private static ScaleData scaleData = null;
    private static int days_passed = 0;

    private static final List<Block> stairs = Arrays.asList(Blocks.STONE_STAIRS, Blocks.ACACIA_STAIRS, Blocks.SANDSTONE_STAIRS, Blocks.SPRUCE_STAIRS, Blocks.SMOOTH_SANDSTONE_STAIRS, Blocks.COBBLESTONE_STAIRS, Blocks.OAK_STAIRS, Blocks.BIRCH_STAIRS, Blocks.DARK_OAK_STAIRS, Blocks.JUNGLE_STAIRS, Blocks.CHERRY_STAIRS, Blocks.STONE_BRICK_STAIRS, Blocks.SANDSTONE_STAIRS, Blocks.PRISMARINE_BRICK_STAIRS);

    private static final List<Item> tools = Arrays.asList(Items.STONE_AXE, Items.STONE_PICKAXE, Items.STONE_HOE, Items.STONE_SWORD, Items.STONE_SHOVEL, Items.WOODEN_AXE, Items.WOODEN_HOE, Items.WOODEN_PICKAXE, Items.GOLDEN_SHOVEL, Items.IRON_HOE, Items.GOLDEN_HELMET, Items.LEATHER_HELMET, Items.IRON_LEGGINGS);

    private static final List<Item> randomCommons = Arrays.asList(Items.SAND, Items.DIRT, Items.OAK_PLANKS, Items.BIRCH_PLANKS, Items.BIRCH_SLAB, Items.APPLE, Items.BEEF, Items.COBBLESTONE, Items.COAL, Items.RAW_COPPER, Items.WHITE_WOOL, Items.SUGAR_CANE, Items.BUCKET, Items.DIORITE, Items.ANDESITE, Items.GRANITE, Items.GRAVEL, Items.TUFF, Items.DEEPSLATE, Items.OAK_SAPLING, Items.RAW_IRON, Items.WHEAT_SEEDS, Items.COARSE_DIRT, Items.GRASS_BLOCK, Items.SCAFFOLDING, Items.REDSTONE_TORCH, Items.LAPIS_LAZULI, Items.PORKCHOP);

    private static final List<Item> randomNonsense = Arrays.asList(Items.BIRCH_LEAVES, Items.ACACIA_LEAVES, Items.BIRCH_LEAVES, Items.BRAIN_CORAL, Items.COBWEB, Items.GRASS, Items.POPPY, Items.DANDELION, Items.ROSE_BUSH, Items.RED_TERRACOTTA, Items.NETHERRACK, Items.CARROT, Items.LIGHT_BLUE_DYE, Items.BAMBOO, Items.CLAY, Items.DARK_OAK_SAPLING, Items.CHERRY_LEAVES, Items.ORANGE_DYE, Items.YELLOW_DYE, Items.GLOWSTONE_DUST, Items.PUMPKIN_SEEDS, Items.BEETROOT_SEEDS, Items.POTATO, Items.SWEET_BERRIES, Items.NETHER_WART, Items.JUNGLE_WOOD);

    private static final List<Block> toughBlocks = Arrays.asList(Blocks.OBSIDIAN, Blocks.POLISHED_DIORITE, Blocks.POLISHED_ANDESITE, Blocks.END_PORTAL, Blocks.END_PORTAL_FRAME, Blocks.END_GATEWAY);
    private static final Logger LOGGER = LogUtils.getLogger();

    private static int deaths = 0;

    @SubscribeEvent
    public static void onAttachCapabilitiesPlayer(AttachCapabilitiesEvent<Entity> event) {
        if(event.getObject() instanceof Player) {
            if(!event.getObject().getCapability(PlayerBloodPressureProvider.PLAYER_BLOOD_PRESSURE).isPresent()) {
                event.addCapability(new ResourceLocation(ThiccMod.MODID, "properties"), new PlayerBloodPressureProvider());
            }
            if(!event.getObject().getCapability(PlayerDementiaProvider.PLAYER_DEMENTIA).isPresent()) {
                event.addCapability(new ResourceLocation(ThiccMod.MODID, "dementia"), new PlayerDementiaProvider());
            }
            if(!event.getObject().getCapability(PlayerScaleProvider.PLAYER_SCALE).isPresent()) {
                event.addCapability(new ResourceLocation(ThiccMod.MODID, "scale"), new PlayerScaleProvider());
            }
            if(!event.getObject().getCapability(PlayerBACProvider.PLAYER_BAC).isPresent()) {
                event.addCapability(new ResourceLocation(ThiccMod.MODID, "bac"), new PlayerBACProvider());
            }
        }
    }

    //public static ScaleData getScaleData(Entity entity) {
    //   return ((PehkuiEntityExtensions)entity).pehkui_getScaleData(ScaleTypes.BASE);
    //}

    @SubscribeEvent
    public static void addCustomTrades(VillagerTradesEvent event) {

        if(event.getType() == ModVillagers.COMPUTER_MASTER.get()) {
            Int2ObjectMap<List<VillagerTrades.ItemListing>> trades = event.getTrades();
            trades.get(1).add((pTrader, pRandom) -> new MerchantOffer(
                    new ItemStack(Items.EMERALD, 16),
                    new ItemStack(ModBlocks.REDDIT_COMPUTER.get(), 1),
                    16, 8, 0.02f));
            trades.get(2).add((pTrader, pRandom) -> new MerchantOffer(
                    new ItemStack(Items.EMERALD, 1),
                    new ItemStack(ModItems.DISCORD_NITRO.get(), 10),
                    5, 12, 0.02f));
        }

        if(event.getType() == ModVillagers.WAFFLE_MASTER.get()) {
            Int2ObjectMap<List<VillagerTrades.ItemListing>> trades = event.getTrades();
            trades.get(1).add((pTrader, pRandom) -> new MerchantOffer(
                    new ItemStack(Items.EMERALD, 1),
                    new ItemStack(ModItems.WAFFLE.get(), 10),
                    5, 12, 0.02f));
        }

        if(event.getType() == ModVillagers.WALMART_MASTER.get()) {
            Int2ObjectMap<List<VillagerTrades.ItemListing>> trades = event.getTrades();
            trades.get(1).add((pTrader, pRandom) -> new MerchantOffer(
                    new ItemStack(Items.EMERALD, 1),
                    new ItemStack(ModItems.BUSCH_LITE.get(), 10),
                    10, 12, 0.02f));
            trades.get(2).add((pTrader, pRandom) -> new MerchantOffer(
                    new ItemStack(Items.EMERALD, 1),
                    new ItemStack(ModItems.PBR.get(), 10),
                    10, 12, 0.02f));
            trades.get(3).add((pTrader, pRandom) -> new MerchantOffer(
                    new ItemStack(Items.EMERALD, 1),
                    new ItemStack(ModItems.WINE.get(), 10),
                    10, 12, 0.02f));
            trades.get(4).add((pTrader, pRandom) -> new MerchantOffer(
                    new ItemStack(Items.EMERALD, 1),
                    new ItemStack(ModItems.MOONSHINE.get(), 10),
                    10, 12, 0.02f));
        }
        if(event.getType() == ModVillagers.LIQUOR_MASTER.get()){
            Int2ObjectMap<List<VillagerTrades.ItemListing>> trades = event.getTrades();
            trades.get(1).add((pTrader, pRandom) -> new MerchantOffer(
                    new ItemStack(Items.EMERALD, 1),
                    new ItemStack(ModItems.BUSCH_LITE.get(), 10),
                    10, 12, 0.02f));
            trades.get(1).add((pTrader, pRandom) -> new MerchantOffer(
                    new ItemStack(Items.EMERALD, 1),
                    new ItemStack(ModItems.PBR.get(), 10),
                    10, 12, 0.02f));
            trades.get(2).add((pTrader, pRandom) -> new MerchantOffer(
                    new ItemStack(Items.EMERALD, 1),
                    new ItemStack(ModItems.MOONSHINE.get(), 10),
                    10, 12, 0.02f));
            trades.get(2).add((pTrader, pRandom) -> new MerchantOffer(
                    new ItemStack(Items.EMERALD, 1),
                    new ItemStack(ModItems.WINE.get(), 10),
                    10, 12, 0.02f));
            trades.get(3).add((pTrader, pRandom) -> new MerchantOffer(
                    new ItemStack(Items.EMERALD, 1),
                    new ItemStack(ModItems.FOURLOKO.get(), 10),
                    10, 12, 0.02f));
            trades.get(3).add((pTrader, pRandom) -> new MerchantOffer(
                    new ItemStack(Items.EMERALD, 1),
                    new ItemStack(ModItems.BOURBON.get(), 10),
                    10, 12, 0.02f));
            trades.get(4).add((pTrader, pRandom) -> new MerchantOffer(
                    new ItemStack(Items.EMERALD, 1),
                    new ItemStack(ModItems.SCOTCH.get(), 5),
                    10, 12, 0.02f));
            trades.get(4).add((pTrader, pRandom) -> new MerchantOffer(
                    new ItemStack(Items.EMERALD, 1),
                    new ItemStack(ModItems.NATTY_DADDY.get(), 20),
                    10, 12, 0.02f));

        }

        if(event.getType() == ModVillagers.MCDONALDS_MASTER.get()) {
            Int2ObjectMap<List<VillagerTrades.ItemListing>> trades = event.getTrades();
            trades.get(1).add((pTrader, pRandom) -> new MerchantOffer(
                    new ItemStack(Items.EMERALD, 1),
                    new ItemStack(ModItems.NUGGIES.get(), 10),
                    10, 12, 0.02f));
            trades.get(2).add((pTrader, pRandom) -> new MerchantOffer(
                    new ItemStack(Items.EMERALD, 1),
                    new ItemStack(ModItems.BIGMAC.get(), 10),
                    10, 12, 0.02f));
            trades.get(3).add((pTrader, pRandom) -> new MerchantOffer(
                    new ItemStack(Items.EMERALD, 1),
                    new ItemStack(ModItems.FRIES.get(), 10),
                    10, 12, 0.02f));
        }

        if(event.getType() == ModVillagers.ARBYS_MASTER.get()) {
            Int2ObjectMap<List<VillagerTrades.ItemListing>> trades = event.getTrades();
            trades.get(1).add((pTrader, pRandom) -> new MerchantOffer(
                    new ItemStack(Items.EMERALD, 1),
                    new ItemStack(ModItems.ARBYSROASTBEEF.get(), 10),
                    10, 12, 0.02f));
            trades.get(2).add((pTrader, pRandom) -> new MerchantOffer(
                    new ItemStack(Items.EMERALD, 1),
                    new ItemStack(ModItems.FRIES.get(), 20),
                    10, 12, 0.02f));
            trades.get(2).add((pTrader, pRandom) -> new MerchantOffer(
                    new ItemStack(Items.EMERALD, 1),
                    new ItemStack(ModItems.MOUNTAINDEW.get(), 20),
                    10, 12, 0.02f));
        }

        if(event.getType() == ModVillagers.CHICFILA_MASTER.get()) {
            Int2ObjectMap<List<VillagerTrades.ItemListing>> trades = event.getTrades();
            trades.get(1).add((pTrader, pRandom) -> new MerchantOffer(
                    new ItemStack(Items.EMERALD, 1),
                    new ItemStack(ModItems.CHICKENSANDWICH.get(), 10),
                    10, 12, 0.02f));
            trades.get(2).add((pTrader, pRandom) -> new MerchantOffer(
                    new ItemStack(Items.EMERALD, 1),
                    new ItemStack(ModItems.FRIES.get(), 10),
                    10, 12, 0.02f));
        }
    }


    @SubscribeEvent
    public static void onPlayerCloned(PlayerEvent.Clone event) {
        if(event.isWasDeath()) {
            event.getOriginal().getCapability(PlayerBloodPressureProvider.PLAYER_BLOOD_PRESSURE).ifPresent(oldStore -> {
                event.getOriginal().getCapability(PlayerBloodPressureProvider.PLAYER_BLOOD_PRESSURE).ifPresent(newStore -> {
                    newStore.copyFrom(oldStore);
                });
            });
            event.getOriginal().getCapability(PlayerDementiaProvider.PLAYER_DEMENTIA).ifPresent(oldStore -> {
                event.getOriginal().getCapability(PlayerDementiaProvider.PLAYER_DEMENTIA).ifPresent(newStore -> {
                    newStore.copyFrom(oldStore);
                });
            });
            event.getOriginal().getCapability(PlayerScaleProvider.PLAYER_SCALE).ifPresent(oldStore -> {
                event.getOriginal().getCapability(PlayerScaleProvider.PLAYER_SCALE).ifPresent(newStore -> {
                    newStore.setScale(scale);
                });
            });
            event.getOriginal().getCapability(PlayerBACProvider.PLAYER_BAC).ifPresent(oldStore -> {
                event.getOriginal().getCapability(PlayerBACProvider.PLAYER_BAC).ifPresent(newStore -> {
                    newStore.copyFrom(oldStore);
                });
            });


        }
    }

    @SubscribeEvent
    public static void onRegisterCapabilities(RegisterCapabilitiesEvent event) {
        event.register(PlayerBloodPressure.class);
        event.register(PlayerDementia.class);
        event.register(PlayerScale.class);
        event.register(PlayerBAC.class);
    }

    @SubscribeEvent
    public static void onPlayerDeath(LivingDeathEvent event){
        if(event.getSource() == event.getEntity().damageSources().cactus()) {
            deaths = deaths + 1;
            //if(scale < 15f) {
            //    scale = scale + 0.05f;
            //}
            //scaleData.setScale(scale);
        }
    }

    @SubscribeEvent
    public static void onPlayerConsume(Finish event){
        if(Arrays.asList(ModItems.BUSCH_LITE.get(), ModItems.NATTY_DADDY.get(), ModItems.MOONSHINE.get(), ModItems.WINE.get(), ModItems.SCOTCH.get(), ModItems.FOURLOKO.get(), ModItems.PBR.get(), ModItems.BOURBON.get()).contains(event.getItem().getItem())){
            LOGGER.info(event.getItem().getDescriptionId());
            event.getEntity().getCapability(PlayerBACProvider.PLAYER_BAC).ifPresent(playerBAC -> {
                playerBAC.addBAC(1);
                drunk_counter = 500;
                if(event.getItem().getItem() == ModItems.SCOTCH.get()){
                    playerBAC.addBAC(2);//stronger liquor means more BAC
                    drunk_counter = 2500;//but also longer time until buzz withdrawal
                }
                if(event.getItem().getItem() == ModItems.BOURBON.get()){
                    playerBAC.addBAC(1);
                    drunk_counter = 1500;
                }
                //reverse tolerance mechanic. when the days get high, BAC goes up more with each drink
                if(days_passed > 6){
                    playerBAC.addBAC(1);
                }
                if(days_passed > 10){
                    playerBAC.addBAC(1);
                }
                if(days_passed > 15){
                    playerBAC.addBAC(1);
                }
                if(days_passed > 20){
                    playerBAC.addBAC(2);
                }
                if(days_passed > 23){
                    playerBAC.addBAC(3);
                }
                LOGGER.info("BAC RAISED TO: " + playerBAC.getBAC());
            });
        }
    }

    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
        ServerPlayer sp = event.player.createCommandSourceStack().getPlayer();
        Level level = event.player.level();
        //FoodData food = event.player.getFoodData();



        if(event.side == LogicalSide.SERVER) {// Discord mod mechanics commented out
            //event.player.getCapability(PlayerBloodPressureProvider.PLAYER_BLOOD_PRESSURE).ifPresent(bloodPressure -> {
                //damage you and raise blood pressure if you are moving too fast
                //if(event.player.getX() - oldX > 4D || event.player.getZ() - oldZ > 4D){// && event.player.getEffect(MobEffects.MOVEMENT_SLOWDOWN) == null){//if player moves more than 1block per tick, damage
                //    event.player.hurt(event.player.damageSources().stalagmite(), 1);
                //    oldX = event.player.getX();
                //    oldZ = event.player.getZ();
                //}

                //if(bloodPressure.getBloodPressure() < 20 && event.player.getRandom().nextFloat() < 0.04f && event.player.isSprinting()) { // Once Every 2 Seconds on Avg while sprinting
                //    bloodPressure.addBloodPressure(1);
                //    ModMessages.sendToPlayer(new BloodPressureDataSyncS2CPacket(bloodPressure.getBloodPressure()), ((ServerPlayer) event.player));
                //    food.setFoodLevel(food.getFoodLevel() - 1);
                //}
                //if(bloodPressure.getBloodPressure() < 20 && event.player.getRandom().nextFloat() < 0.5f && event.player.isUsingItem()) { // Once Every 10 Seconds on Avg while using an item
                    //if(event.player.getDeltaMovement().x() > 1f) {
                     //   bloodPressure.addBloodPressure(1);
                    //}
                    //ModMessages.sendToPlayer(new BloodPressureDataSyncS2CPacket(bloodPressure.getBloodPressure()), ((ServerPlayer) event.player));
                //}

                //Destroy the block the player is standing on, as well as all the blocks immediately around it. This simulates the player sinking into the earth cuz they so thicc
                //int blocksToDestroy = (int) (2.6f*scale + 1);
                //blocksToDestroy = blocksToDestroy*blocksToDestroy;
                /*if(event.player.getRandom().nextFloat() < 0.0023f*scale*scale && !toughBlocks.contains(event.player.getBlockStateOn().getBlock())){
                    BlockPos bp = event.player.blockPosition().below();
                    BlockPos bpAbove = bp.above();
                    destroyBlocksWithinRadius(bp, level, blocksToDestroy);
                }
                if(!toughBlocks.contains(event.player.getBlockStateOn().getBlock())) {
                    BlockPos playerbp = event.player.blockPosition();
                    AABB pArea = new AABB(playerbp.getX() - 5D*scale, playerbp.getY() - 1D*scale, playerbp.getZ() - 5D*scale, playerbp.getX() + 5D*scale, playerbp.getY() + 3D*scale, playerbp.getZ() + 5D*scale);
                    List<Entity> renderedEntities = level.getEntities(event.player, pArea);
                    for (Entity e : renderedEntities) {
                        if(e.isPushable()) {
                            e.hurt(event.player.damageSources().cactus(), 1f);
                            pull(e, event);
                        }
                    }
                }*/

                //if(event.player.isUnderWater() && event.player.getRandom().nextFloat() < 0.005f){//blood pressure increases while under water
                    //food.setFoodLevel(food.getFoodLevel() - 1);
                //    bloodPressure.addBloodPressure(1);
                //}
                //raise blood pressure if mining, swinging sword/axe, etc.
                //if(event.player.swinging && event.player.getRandom().nextFloat() < 0.025f){
                //    bloodPressure.addBloodPressure(1);
                //}
                //raises blood pressure if the player is swimming
                //if(bloodPressure.getBloodPressure() < 20 && event.player.getRandom().nextFloat() < 0.005f && event.player.isSwimming()) {
                //    bloodPressure.addBloodPressure(1);
                    //food.setFoodLevel(food.getFoodLevel() - 1);
                //    ModMessages.sendToPlayer(new BloodPressureDataSyncS2CPacket(bloodPressure.getBloodPressure()), ((ServerPlayer) event.player));
                //}
                //raises blood pressure if the player is airborn
                //if(bloodPressure.getBloodPressure() < 20 && event.player.getRandom().nextFloat() < 0.05f && !(event.player.onGround()) && !(event.player.isInWater()) && !(event.player.isUnderWater()) && !(event.player.isUsingItem()) && !(event.player.isPassenger())) { // Once Every 1 Seconds on Avg while airborn
                //    bloodPressure.addBloodPressure(1);
                //    ModMessages.sendToPlayer(new BloodPressureDataSyncS2CPacket(bloodPressure.getBloodPressure()), ((ServerPlayer) event.player));
                //}
                //lowers blood pressure if the player is not doing anything to raise it
                //if(bloodPressure.getBloodPressure() > 0 && event.player.getRandom().nextFloat() < 0.02f && !(event.player.isSprinting()) && !(event.player.isSwimming()) && !(event.player.isUsingItem()) && !event.player.swinging) {//regen 1 every 2.5 seconds if not running and not swimming and not using item and not airborn
                //    bloodPressure.subBloodPressure(1);
                //    ModMessages.sendToPlayer(new BloodPressureDataSyncS2CPacket(bloodPressure.getBloodPressure()), ((ServerPlayer) event.player));
                //}

                // if your blood pressure is too high, this kills you
                //if(bloodPressure.getBloodPressure() >= 20) {
                //    DamageSource damageSource = new DamageSource(null);
                //    event.player.playSound(SoundEvents.PIG_DEATH, Float.MAX_VALUE,1.0f);
                //    event.player.hurt(event.player.damageSources().generic(), Float.MAX_VALUE);
                //}

                // hurts the player if they are standing on grass
                /*if(event.player.getBlockStateOn().getBlock() == Blocks.GRASS_BLOCK || event.player.getFeetBlockState().is(Blocks.GRASS) || event.player.getFeetBlockState().is(Blocks.TALL_GRASS)){
                    event.player.hurt(event.player.damageSources().cactus(), 1.0f);//damage discord mods if touching grass
                }*/

                //hurts the player if they are standing on stairs
                //if(stairs.contains(event.player.getBlockStateOn().getBlock())){
                //    event.player.hurt(event.player.damageSources().cactus(), 5.0f);
                //}
                //increases the rate at which hunger diminishes
                //kill the player for not eating enough
                //if(food.getFoodLevel() < 6){
                //    event.player.hurt(event.player.damageSources().starve(), Float.MAX_VALUE);
                    //event.player.playSound(SoundEvents.PIG_DEATH, Float.MAX_VALUE,1.0f);
                //}

                //if(event.player.getRandom().nextFloat() < 0.0001f){
                //    Inventory inventory = event.player.getInventory();
                //    inventory.add(new ItemStack(ModItems.POOP.get(), 1));
                //}


            //});
            //.005f = once every 10 seconds
            //.001f = once every 50 seconds
            //.0001 = once every 500 seconds on average
            //.00005 = once every 1000 seconds on average
            /*event.player.getCapability(PlayerScaleProvider.PLAYER_SCALE).ifPresent(sc -> {
                if(scale > sc.getScale()) {
                    sc.setScale(scale);
                    scaleData.setScale(scale);
                }
                else{
                    scale = sc.getScale();
                    scaleData.setScale(scale);
                }
                //LOGGER.info("current scale is: " + sc.getScale());

            });*/

            //BAC mechanics go here
            event.player.getCapability(PlayerBACProvider.PLAYER_BAC).ifPresent(bac -> {
                if(drunk_counter > 0){
                    drunk_counter--;
                }
                //kill player when BAC is too high
                if(bac.getBAC() == 40){
                    event.player.hurt(event.player.damageSources().starve(), Float.MAX_VALUE);
                }
                // withdrawal damage every tick when sober
                if(bac.getBAC() == 0 || drunk_counter == 0){
                    event.player.hurt(event.player.damageSources().stalagmite(), 1f);
                }
                //low level nausea
                if(bac.getBAC() > 2 && event.player.getEffect(MobEffects.CONFUSION) == null){
                    //mechanics for increasing severity nausea. 'increasing' means longer duration, because the warped screen effect is stronger the longer the effect lasts
                    //at first, we want 1 second, with increasing to maybe 15 at its worst
                    if(bac.getBAC() < 5  && sp != null){
                        sp.addEffect(new MobEffectInstance(MobEffects.CONFUSION, 20, 1));
                    }
                    else if (bac.getBAC() < 15 && sp != null){
                        sp.addEffect(new MobEffectInstance(MobEffects.CONFUSION, 100, 1));
                    }
                    else if (bac.getBAC() < 20 && sp != null){
                        sp.addEffect(new MobEffectInstance(MobEffects.CONFUSION, 140, 1));
                        sp.addEffect(new MobEffectInstance(MobEffects.HUNGER, 140, 1));
                    }
                    else if (bac.getBAC() < 25 && sp != null){
                        sp.addEffect(new MobEffectInstance(MobEffects.CONFUSION, 200, 1));
                        sp.addEffect(new MobEffectInstance(MobEffects.HUNGER, 200, 1));
                        sp.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 200, 1));
                    }
                    else if (bac.getBAC() < 30 && sp != null){
                        sp.addEffect(new MobEffectInstance(MobEffects.CONFUSION, 300, 1));
                        sp.addEffect(new MobEffectInstance(MobEffects.HUNGER, 300, 1));
                        sp.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 300, 1));
                        sp.addEffect(new MobEffectInstance(MobEffects.DIG_SLOWDOWN, 300, 1));
                    }
                    else if (bac.getBAC() < 35 && sp != null){
                        sp.addEffect(new MobEffectInstance(MobEffects.CONFUSION, 400, 1));
                        sp.addEffect(new MobEffectInstance(MobEffects.HUNGER, 400, 1));
                        sp.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 400, 1));
                        sp.addEffect(new MobEffectInstance(MobEffects.DIG_SLOWDOWN, 400, 1));
                        sp.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 400, 1));

                    }
                    else if (bac.getBAC() >= 35 && sp != null){
                        sp.addEffect(new MobEffectInstance(MobEffects.CONFUSION, 500, 1));
                        sp.addEffect(new MobEffectInstance(MobEffects.HUNGER, 500, 1));
                        sp.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 500, 1));
                        sp.addEffect(new MobEffectInstance(MobEffects.DIG_SLOWDOWN, 500, 1));
                        sp.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 500, 1));
                        sp.addEffect(new MobEffectInstance(MobEffects.UNLUCK, 500, 1));
                    }
                }
                //BAC slowly goes down over time
                if(event.player.getRandom().nextFloat() < 0.0001f){
                    bac.subBAC(1);
                }
                //send BAC Meter update
                ModMessages.sendToPlayer(new BACDataSyncS2CPacket(bac.getBAC()), sp);
                //update days_passed
                days_passed = Math.toIntExact(event.player.level().getGameTime() / 24000);
                bloodAlcoholContent = bac.getBAC();
                //kill entities that I run into in truck or mobility scooter
                if(event.player.isPassenger()){
                    Entity f = event.player.getControlledVehicle();
                    BlockPos playerbp = event.player.blockPosition();
                    AABB pArea = new AABB(playerbp.getX() - 1.5D, playerbp.getY() - 1D, playerbp.getZ() - 1.5D, playerbp.getX() + 1.5D, playerbp.getY() + 1D, playerbp.getZ() + 1.5D);
                    List<Entity> renderedEntities = level.getEntities(event.player, pArea);
                    for (Entity e : renderedEntities) {
                        if(e.isPushable()) {
                            e.hurt(event.player.damageSources().cactus(), 20f);
                            if(e.getType() == EntityType.IRON_GOLEM && f != null){
                                f.hurt(event.player.damageSources().generic(), 10f);
                            }
                            if(e.getType() == EntityType.COW && f != null){
                                f.hurt(event.player.damageSources().generic(), 2f);
                            }
                            if(e.getType() == EntityType.PIG && f != null){
                                f.hurt(event.player.damageSources().generic(), 1f);
                            }
                            if(e.getType() == EntityType.ENDERMAN && f != null){
                                f.hurt(event.player.damageSources().generic(), 3f);
                            }
                        }
                        if(e.getType() == EntityType.ENDER_DRAGON && f != null){
                            e.hurt(event.player.damageSources().cactus(), 10);
                            f.hurt(event.player.damageSources().generic(), 25f);
                        }
                    }
                }
                if(true){
                    BlockPos bp = event.player.blockPosition();
                    AABB introvertZone = new AABB(bp.getX() - 10D, bp.getY() - 10D, bp.getZ() - 10D, bp.getX() + 10D, bp.getY() + 10D, bp.getZ() + 10D);
                    List<Entity> renderedEntities = level.getEntities(event.player, introvertZone);
                    for (Entity e : renderedEntities) {
                        if(e.isPushable() && boomCounter == 0) {
                            event.player.level().explode(e, bp.getX(), bp.getY(), bp.getZ(), 5f, Level.ExplosionInteraction.MOB);
                            boomCounter = 1500;
                        }
                    }

                }
                if(boomCounter == 0){
                    boomCounter = 1500;
                }

            });

            //dementia mechanics start here
            event.player.getCapability(PlayerDementiaProvider.PLAYER_DEMENTIA).ifPresent(dementia -> {
                if(dementia.getDementia() > 1){//if we have a dementia episode, we need to count down the ticks until memory loss
                    dementia.subDementia(1);
                }

                if(dementia.getDementia() == 0 && event.player.getRandom().nextFloat() < 0.0004f && bloodAlcoholContent > 30){//about once every 20 seconds once BAC is sufficiently high
                    //start darkness effect
                    sp.addEffect(new MobEffectInstance(MobEffects.DARKNESS, 400));
                    dementia.setMaxDementia();
                }

                if(dementia.getDementia() == 1){
                    long days = level.getGameTime() / 24000;
                    LOGGER.info("the number of days is " + days);
                    float daysPercent = days * 0.01f;
                    if(daysPercent > 0.33f){
                        daysPercent = .33f;
                    }
                    dementia.subDementia(1);
                    //teleport the player randomly
                    BlockPos bp = sp.getRespawnPosition();
                    BlockPos cp = event.player.blockPosition();
                    Inventory inventory = event.player.getInventory();

                    int randDelete = event.player.getRandom().nextInt(40);
                    int randOne = event.player.getRandom().nextInt(40);
                    int randTwo = event.player.getRandom().nextInt(40);
                    int randThree = event.player.getRandom().nextInt(40);
                    int randFour = event.player.getRandom().nextInt(40);
                    int randFive = event.player.getRandom().nextInt(40);
                    int randTools = event.player.getRandom().nextInt(12);
                    int randCommons = event.player.getRandom().nextInt(26);
                    int randCommonsTwo = event.player.getRandom().nextInt(21);
                    int randCommonsStack = event.player.getRandom().nextInt(37);
                    int randNonsenseStack = event.player.getRandom().nextInt(48);

                    inventory.setItem(randDelete, ItemStack.EMPTY);//randomly delete one of the player's items.
                    inventory.setItem(randOne, new ItemStack(tools.get(randTools)));
                    inventory.setItem(randTwo, new ItemStack(randomCommons.get(randCommons), randCommonsStack));
                    inventory.setItem(randThree, new ItemStack(randomNonsense.get(randCommons), randNonsenseStack));
                    inventory.setItem(randFour, new ItemStack(randomCommons.get(randCommonsTwo), randNonsenseStack));
                    inventory.setItem(randFive, new ItemStack(randomNonsense.get(randCommonsTwo), randCommonsStack));

                    if (days > 15 && event.player.getRandom().nextFloat() < 0.1f + daysPercent){
                        sp.addEffect(new MobEffectInstance(MobEffects.CONFUSION, 2000));
                    }

                    if (event.player.getRandom().nextFloat() < daysPercent){
                        sp.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 8000));
                    }

                    if(event.player.getRandom().nextFloat() > .95f){
                        sp.addEffect(new MobEffectInstance(MobEffects.DIG_SLOWDOWN, 8000));
                    }

                    if(event.player.getRandom().nextFloat() < daysPercent){
                        sp.addEffect(new MobEffectInstance(MobEffects.HUNGER, 2000));
                    }




                    if (event.player.getRandom().nextFloat() < 0.2f && bp != null && level.dimensionType().bedWorks()) {
                        event.player.teleportTo(bp.getX(), bp.getY(), bp.getZ());
                        sp.removeEffect(MobEffects.DARKNESS);
                        sp.removeEffect(MobEffects.MOVEMENT_SLOWDOWN);
                    }
                    else{
                        long ticks = level.getGameTime();
                        long additive = ticks / 24000;
                        long multiplier = additive + 210;
                        double xOffset = event.player.getRandom().nextDouble() * multiplier;
                        double zOffset = event.player.getRandom().nextDouble() * multiplier;
                        if(event.player.getRandom().nextFloat() > 0.5f){
                            xOffset = xOffset - xOffset - xOffset;//make xOffset negative sometimes
                        }
                        if(event.player.getRandom().nextFloat() > 0.5f){
                            zOffset = zOffset - zOffset - zOffset;
                        }
                        BlockPos blockpos = BlockPos.containing(cp.getX() + xOffset, 250D, cp.getZ() + zOffset);
                        double d3 = 250D;
                        boolean flag1 = false;


                        while(!flag1 && blockpos.getY() > level.getMinBuildHeight()) {//look for the highest block at the xz coords that isn't air
                            BlockPos blockposbelow = blockpos.below();
                            BlockState blockstatebelow = level.getBlockState(blockposbelow);
                            BlockState blockstate = level.getBlockState(blockpos);
                            BlockPos blockposabove = blockpos.above();
                            BlockState blockstateabove = level.getBlockState(blockposabove);
                            if (!blockstatebelow.isAir() && blockstateabove.isAir() && blockstate.isAir() && !blockstatebelow.is(Blocks.LAVA) && !blockstatebelow.is(Blocks.BEDROCK)) {
                                flag1 = true;
                            } else {
                                --d3;
                                blockpos = blockposbelow;
                            }
                        }

                        if (flag1) {
                            if(event.player.getRandom().nextFloat() < 0.1f){
                                inventory.add(new ItemStack(ModItems.POOP.get(), 1));
                            }
                            event.player.teleportTo(blockpos.getX(), d3, blockpos.getZ());
                            if(daysPercent < event.player.getRandom().nextFloat()){
                                sp.addEffect(new MobEffectInstance(MobEffects.DARKNESS, 8000));
                            }
                            else{
                                sp.removeEffect(MobEffects.DARKNESS);
                            }
                            sp.removeEffect(MobEffects.MOVEMENT_SLOWDOWN);
                            if(event.player.getRandom().nextFloat() < 0.05f){//5% chance to change respawn position on random teleport
                                sp.setRespawnPosition(level.dimension(), blockpos, 0,true,  false);
                            }
                        }
                    }
                }
            });

        }
        if(event.side == LogicalSide.CLIENT){
            event.player.getCapability(PlayerBACProvider.PLAYER_BAC).ifPresent(bac -> {
                float stumbler = bac.getBAC() * bac.getBAC() * 0.0001f;
                if(event.player.getRandom().nextFloat() < stumbler && !event.player.isPassenger() && event.player.onGround()) {
                    double xpush = 0.3d;
                    double zpush = 0.3d;
                    if (event.player.getRandom().nextBoolean()) {
                        xpush = -1d * xpush;
                    }
                    if (event.player.getRandom().nextBoolean()) {
                        zpush = -1d * xpush;
                    }
                    event.player.setDeltaMovement(xpush, 0.0, zpush);
                }
                if(event.player.isPassenger() && event.player.getRandom().nextFloat() * 3 < stumbler){

                }
            });
        }
    }

    @SubscribeEvent
    public static void onPlayerSleep(PlayerSleepInBedEvent event){
        event.getEntity().getCapability(PlayerBACProvider.PLAYER_BAC).ifPresent(bac -> {
            if(bac.getBAC() > 20){//hangover effect
                event.getEntity().addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 2000, 2));
            }
            if(bac.getBAC() >= 10){//we should lose BAC upon sleeping
                bac.subBAC(10);
            }
        });
    }

    @SubscribeEvent
    public static void onPlayerJoinWorld(EntityJoinLevelEvent event) {
        int days = Math.toIntExact(event.getLevel().getGameTime() / 24000);
        if(!event.getLevel().isClientSide()) {
            if(event.getEntity() instanceof ServerPlayer player) {
                //scaleData = getScaleData(player);
                player.getCapability(PlayerBloodPressureProvider.PLAYER_BLOOD_PRESSURE).ifPresent(thirst -> {
                    ModMessages.sendToPlayer(new BloodPressureDataSyncS2CPacket(thirst.getBloodPressure()), player);
                });
                /*player.getCapability(PlayerScaleProvider.PLAYER_SCALE).ifPresent(sc -> {
                    ModMessages.sendToPlayer(new ScaleDataSyncS2CPacket(sc.getScale()), player);
                    if(scale > sc.getScale()) {
                        sc.setScale(scale);
                        //scaleData.setScale(scale);
                    }
                    else{
                        scale = sc.getScale();
                        //scaleData.setScale(scale);
                    }
                });*/
                player.getCapability(PlayerBACProvider.PLAYER_BAC).ifPresent(bac -> {
                    ModMessages.sendToPlayer(new BACDataSyncS2CPacket(bac.getBAC()), player);
                });

                player.addItem(new ItemStack(ModItems.BUSCH_LITE.get(), 10 - (days /  2)));
                player.addItem(new ItemStack(Items.EMERALD, 10 - (days /  2)));
                if(player.getName().getString() == "Troggy_T"){
                    player.addItem(new ItemStack(Items.SNOWBALL, 64));
                }

            }
        }
    }

    private static void destroyNineBlocks(BlockPos bp, Level level){
        BlockPos bp2 = bp.east();
        BlockPos bp3 = bp.west();
        BlockPos bp4 = bp.south();
        BlockPos bp5 = bp.north();
        BlockPos bp6 = bp5.west();
        BlockPos bp7 = bp5.east();
        BlockPos bp8 = bp4.west();
        BlockPos bp9 = bp4.east();
        level.destroyBlock(bp, false);
        level.destroyBlock(bp2, false);
        level.destroyBlock(bp3, false);
        level.destroyBlock(bp4, false);
        level.destroyBlock(bp5, false);
        level.destroyBlock(bp6, false);
        level.destroyBlock(bp7, false);
        level.destroyBlock(bp8, false);
        level.destroyBlock(bp9, false);
    }

    private static void destroyBlocksWithinRadius(BlockPos bp, Level level, int numOfBlocksToDestroy){
        int direction = 0;
        int blocksLeftInThisRow = 1;
        int blocksToDestroyInNextRow = 1;
        boolean increaseBlocks = false;
        for(int i = 0; i < numOfBlocksToDestroy; i++){
            level.destroyBlock(bp, false);
            blocksLeftInThisRow--;
            if(direction == 0){
                bp = bp.north();
                if(blocksLeftInThisRow == 0){
                    direction = 1;
                    increaseBlocks = !increaseBlocks;
                    if(!increaseBlocks){
                        blocksToDestroyInNextRow++;
                    }
                    blocksLeftInThisRow = blocksToDestroyInNextRow;
                }
            }
            else if(direction == 1){
                bp = bp.east();
                if(blocksLeftInThisRow == 0){
                    direction = 2;
                    increaseBlocks = !increaseBlocks;
                    if(!increaseBlocks){
                        blocksToDestroyInNextRow++;
                    }
                    blocksLeftInThisRow = blocksToDestroyInNextRow;
                }
            }
            else if(direction == 2){
                bp = bp.south();
                if(blocksLeftInThisRow == 0){
                    direction = 3;
                    increaseBlocks = !increaseBlocks;
                    if(!increaseBlocks){
                        blocksToDestroyInNextRow++;
                    }
                    blocksLeftInThisRow = blocksToDestroyInNextRow;
                }
            }
            else if(direction == 3){
                bp = bp.west();
                if(blocksLeftInThisRow == 0){
                    direction = 0;
                    increaseBlocks = !increaseBlocks;
                    if(!increaseBlocks){
                        blocksToDestroyInNextRow++;
                    }
                    blocksLeftInThisRow = blocksToDestroyInNextRow;
                }
            }
        }
    }
    public static void pull(Entity pEntity, TickEvent.PlayerTickEvent event) {
        if (!event.player.isPassengerOfSameVehicle(pEntity) && !pEntity.noPhysics && !event.player.noPhysics) {
            double d0 = pEntity.getX() - event.player.getX();
            double d1 = pEntity.getZ() - event.player.getZ();
            double d2 = Mth.absMax(d0, d1);
            if (d2 >= 0.009999999776482582) {
                d2 = Math.sqrt(d2);
                d0 /= d2;
                d1 /= d2;
                double d3 = 1.0 / d2;
                if (d3 > 1.0) {
                    d3 = 1.0;
                }

                d0 *= d3;
                d1 *= d3;
                d0 *= 0.05000000074505806;
                d1 *= 0.05000000074505806;
                //if (!pEntity.isVehicle() && pEntity.isPushable()) {
                //    event.player.push(-d0, 0.0, -d1);
                //}

                if (!pEntity.isVehicle() && pEntity.isPushable()) {
                    pEntity.push(-d0, 0.0, -d1);
                }
            }
        }

    }
}
