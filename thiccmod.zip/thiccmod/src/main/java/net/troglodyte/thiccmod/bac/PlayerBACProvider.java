package net.troglodyte.thiccmod.bac;

import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.common.capabilities.CapabilityManager;
import net.minecraftforge.common.capabilities.CapabilityToken;
import net.minecraftforge.common.capabilities.ICapabilityProvider;
import net.minecraftforge.common.util.INBTSerializable;
import net.minecraftforge.common.util.LazyOptional;
import net.troglodyte.thiccmod.bac.PlayerBAC;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class PlayerBACProvider implements ICapabilityProvider, INBTSerializable<CompoundTag> {
    public static Capability<PlayerBAC> PLAYER_BAC = CapabilityManager.get(new CapabilityToken<PlayerBAC>() { });

    private PlayerBAC bac = null;
    private final LazyOptional<PlayerBAC> optional = LazyOptional.of(this::createPlayerBAC);

    private PlayerBAC createPlayerBAC() {
        if(this.bac == null) {
            this.bac = new PlayerBAC();
        }

        return this.bac;
    }

    @Override
    public @NotNull <T> LazyOptional<T> getCapability(@NotNull Capability<T> cap, @Nullable Direction side) {
        if(cap == PLAYER_BAC) {
            return optional.cast();
        }

        return LazyOptional.empty();
    }

    @Override
    public CompoundTag serializeNBT() {
        CompoundTag nbt = new CompoundTag();
        createPlayerBAC().saveNBTData(nbt);
        return nbt;
    }

    @Override
    public void deserializeNBT(CompoundTag nbt) {
        createPlayerBAC().loadNBTData(nbt);
    }
}
