package net.troglodyte.thiccmod.worldgen.biome;

import net.minecraft.resources.ResourceLocation;
import net.troglodyte.thiccmod.ThiccMod;
import terrablender.api.Regions;

public class ModTerraBlender {
    public static void registerBiomes() {
        Regions.register(new ModOverworldRegion(new ResourceLocation(ThiccMod.MODID, "overworld"), 2));
    }
}
