package net.troglodyte.thiccmod.block.entity.renderer;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderer;
import net.minecraft.world.phys.Vec3;
import net.troglodyte.thiccmod.block.entity.HelenKellerBlockEntity;

public class HelenKellerBlockEntityRenderer implements BlockEntityRenderer<HelenKellerBlockEntity> {
    @Override
    public void render(HelenKellerBlockEntity helenKellerBlockEntity, float v, PoseStack poseStack, MultiBufferSource multiBufferSource, int i, int i1) {

    }

    @Override
    public boolean shouldRenderOffScreen(HelenKellerBlockEntity pBlockEntity) {
        return BlockEntityRenderer.super.shouldRenderOffScreen(pBlockEntity);
    }

    @Override
    public int getViewDistance() {
        return BlockEntityRenderer.super.getViewDistance();
    }

    @Override
    public boolean shouldRender(HelenKellerBlockEntity pBlockEntity, Vec3 pCameraPos) {
        return BlockEntityRenderer.super.shouldRender(pBlockEntity, pCameraPos);
    }
}
