package net.troglodyte.thiccmod.client;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.logging.LogUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraftforge.client.gui.overlay.IGuiOverlay;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.main.GameConfig;
import net.troglodyte.thiccmod.ThiccMod;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.resources.ResourceLocation;
import net.troglodyte.thiccmod.bloodpressure.PlayerBloodPressureProvider;
import net.troglodyte.thiccmod.networking.ModMessages;
import net.troglodyte.thiccmod.networking.packet.BloodPressureDataSyncS2CPacket;
import org.slf4j.Logger;

public class BloodPressureHudOverlay {

    private static final ResourceLocation FILLED_BLOODPRESSURE = new ResourceLocation(ThiccMod.MODID,
            "textures/blood_pressure/filled_blood_pressure.png");
    private static final ResourceLocation EMPTY_BLOODPRESSURE = new ResourceLocation(ThiccMod.MODID,
            "textures/blood_pressure/empty_blood_pressure.png");

    private static final Logger LOGGER = LogUtils.getLogger();


    protected static Minecraft mc = Minecraft.getInstance();
    protected static MultiBufferSource.BufferSource bufferSource = mc.renderBuffers().bufferSource();



    static GuiGraphics guiGraphics = new GuiGraphics(mc, bufferSource);

    public static final IGuiOverlay HUD_BLOODPRESSURE = ((gui, poseStack, partialTick, width, height) -> {
        int x = width / 2;
        int y = height;

        RenderSystem.setShader(GameRenderer::getPositionTexShader);
        RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
        RenderSystem.setShaderTexture(0, EMPTY_BLOODPRESSURE);


        for(int i = 0; i < 20; i++) {
            guiGraphics.blit(EMPTY_BLOODPRESSURE,x - 90 + (i * 4), y - 52,0,0,6,12,
                    6,12);
        }
        RenderSystem.setShaderTexture(0, FILLED_BLOODPRESSURE);
        for(int i = 0; i < 20; i++) {
            if(ClientBloodPressureData.getPlayerBloodPressure() > i) {
                guiGraphics.blit(FILLED_BLOODPRESSURE,x - 90 + (i * 4),y - 52,0,0,6,12,
                        6,12);
            } else {
                break;
            }
        }

    });

}
