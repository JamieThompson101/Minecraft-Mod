package net.troglodyte.thiccmod.bac;

import net.minecraft.nbt.CompoundTag;
import net.troglodyte.thiccmod.bloodpressure.PlayerBloodPressure;

public class PlayerBAC {

    private int bac;

    private final int MIN_BAC = 0;
    private final int MAX_BAC = 40;

    public int getBAC(){return bac;}

    public void addBAC(int add){this.bac = Math.min(bac + add, MAX_BAC);}

    public void subBAC(int sub){this.bac = Math.max(bac - sub, MIN_BAC);}

    public void copyFrom(PlayerBAC source) {
        this.bac = source.bac;
    }

    public void saveNBTData(CompoundTag nbt) {
        nbt.putInt("bac", bac);
    }

    public void loadNBTData(CompoundTag nbt) {
        bac = nbt.getInt("bac");
    }

}
