package net.troglodyte.thiccmod.entity.client;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;
import net.troglodyte.thiccmod.ThiccMod;
import net.troglodyte.thiccmod.entity.custom.DiscordKittenEntity;

public class DiscordKittenRenderer extends MobRenderer<DiscordKittenEntity, DiscordKittenModel<DiscordKittenEntity>> {
    public DiscordKittenRenderer(EntityRendererProvider.Context pContext) {
        super(pContext, new DiscordKittenModel<>(pContext.bakeLayer(ModModelLayers.DISCORD_KITTEN_LAYER)), 1.2f);
    }

    @Override
    public ResourceLocation getTextureLocation(DiscordKittenEntity pEntity) {
        return new ResourceLocation(ThiccMod.MODID,"textures/mob/discord_kitten.png");
    }

    @Override
    public void render(DiscordKittenEntity pEntity, float pEntityYaw, float pPartialTicks, PoseStack pMatrixStack, MultiBufferSource pBuffer, int pPackedLight) {
        if(pEntity.isBaby()){
            pMatrixStack.scale(.5f, .5f, .5f);
        }

        super.render(pEntity, pEntityYaw, pPartialTicks, pMatrixStack, pBuffer, pPackedLight);
    }
}
