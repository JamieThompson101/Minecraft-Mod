package net.troglodyte.thiccmod.networking.packet;

import net.minecraft.ChatFormatting;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.level.block.Blocks;
import net.minecraftforge.network.NetworkEvent;
import net.troglodyte.thiccmod.dementia.PlayerDementiaProvider;
import net.troglodyte.thiccmod.networking.ModMessages;

import java.util.function.Supplier;

public class DementiaC2S {

    private static final String MESSAGE_LOWER_DEMENTIA = "message.thiccmod.lowerdementia";
    private static final String MESSAGE_TOO_LATE_TO_LOWER_DEMENTIA = "message.thiccmod.toolatedementia";

    public DementiaC2S() {

    }

    public DementiaC2S(FriendlyByteBuf buf) {

    }

    public void toBytes(FriendlyByteBuf buf) {

    }

    public boolean handle(Supplier<NetworkEvent.Context> supplier) {
        NetworkEvent.Context context = supplier.get();
        context.enqueueWork(() -> {
            // HERE WE ARE ON THE SERVER!
            ServerPlayer player = context.getSender();
            ServerLevel level = player.serverLevel();

            if(hasWaterAroundThem(player, level, 2)) {
                // Notify the player that water has been drunk
                player.sendSystemMessage(Component.translatable(MESSAGE_LOWER_DEMENTIA).withStyle(ChatFormatting.DARK_RED));
                // play the drinking sound
                level.playSound(null, player.getOnPos(), SoundEvents.GENERIC_DRINK, SoundSource.PLAYERS,
                        0.5F, level.random.nextFloat() * 0.1F + 0.9F);

                // increase the water level / thirst level of player
                // Output the current thirst level
                player.getCapability(PlayerDementiaProvider.PLAYER_DEMENTIA).ifPresent(dementia -> {
                    dementia.subDementia(1);
                    player.sendSystemMessage(Component.literal("Current BloodPressure " + dementia.getDementia())
                            .withStyle(ChatFormatting.RED));
                    ModMessages.sendToPlayer(new BloodPressureDataSyncS2CPacket(dementia.getDementia()), player);
                });


            } else {
                // Notify the player that there is no water around!
                player.sendSystemMessage(Component.translatable(MESSAGE_TOO_LATE_TO_LOWER_DEMENTIA).withStyle(ChatFormatting.RED));
                // Output the current thirst level
                player.getCapability(PlayerDementiaProvider.PLAYER_DEMENTIA).ifPresent(thirst -> {
                    player.sendSystemMessage(Component.literal("Current Thirst " + thirst.getDementia())
                            .withStyle(ChatFormatting.AQUA));
                    ModMessages.sendToPlayer(new BloodPressureDataSyncS2CPacket(thirst.getDementia()), player);
                });
            }
        });
        return true;
    }

    private boolean hasWaterAroundThem(ServerPlayer player, ServerLevel level, int size) {

        return level.getBlockStates(player.getBoundingBox().inflate(size))
                .filter(state -> state.is(Blocks.WATER)).toArray().length > 0;
    }
}
