package net.troglodyte.thiccmod.item;

import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.food.FoodProperties;

public class ModFoods {
    public static final FoodProperties BORGAR = new FoodProperties.Builder().nutrition(4).build();
    public static final FoodProperties DORITOS = new FoodProperties.Builder().nutrition(3).build();

    public static final FoodProperties FRIES = new FoodProperties.Builder().nutrition(4).build();
    public static final FoodProperties NUGGIES = new FoodProperties.Builder().nutrition(4).build();
    public static final FoodProperties BBQSAUCE = new FoodProperties.Builder().nutrition(2).build();
    public static final FoodProperties BIGMAC = new FoodProperties.Builder().nutrition(6).build();
    public static final FoodProperties ARBYSROASTBEEF = new FoodProperties.Builder().nutrition(6).build();
    public static final FoodProperties CHICKENSANDWICH = new FoodProperties.Builder().nutrition(8).build();

    public static final FoodProperties SPICYRAMEN = new FoodProperties.Builder().nutrition(2).build();
    public static final FoodProperties SPICYTAKIS = new FoodProperties.Builder().nutrition(2).build();

    public static final FoodProperties BUSCH_LITE = new FoodProperties.Builder().nutrition(1).alwaysEat().build();

    public static final FoodProperties BOURBON = new FoodProperties.Builder().nutrition(1).alwaysEat().build();

    public static final FoodProperties WINE = new FoodProperties.Builder().nutrition(1).alwaysEat().build();

    public static final FoodProperties NATTY_DADDY = new FoodProperties.Builder().nutrition(1).alwaysEat().build();
    public static final FoodProperties SCOTCH = new FoodProperties.Builder().nutrition(2).alwaysEat().build();
    public static final FoodProperties PBR = new FoodProperties.Builder().nutrition(1).alwaysEat().build();
    public static final FoodProperties MOONSHINE = new FoodProperties.Builder().nutrition(1).alwaysEat().build();
    public static final FoodProperties FOURLOKO = new FoodProperties.Builder().nutrition(1).alwaysEat().effect(() -> new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 2000), 1).build();

    public static final FoodProperties MOUNTAINDEW = new FoodProperties.Builder().nutrition(2).saturationMod(1).effect(() -> new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 2000), 1).build();
    public static final FoodProperties ANTIDEPRESSANT = new FoodProperties.Builder().nutrition(0).alwaysEat().effect(() -> new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 2000), 1).build();

    public static final FoodProperties WAFFLE = new FoodProperties.Builder().nutrition(10).build();


    public static final FoodProperties POOP = new FoodProperties.Builder().nutrition(1).effect(() -> new MobEffectInstance(MobEffects.POISON, 2000), 1).build();

}
