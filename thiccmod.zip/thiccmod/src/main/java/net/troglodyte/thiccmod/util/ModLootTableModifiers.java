package net.troglodyte.thiccmod.util;


public class ModLootTableModifiers {
    public static void modifyLootTables(){

    }
}
