package net.troglodyte.thiccmod.entity;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.npc.Villager;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;
import net.troglodyte.thiccmod.ThiccMod;
import net.troglodyte.thiccmod.entity.custom.DiscordKittenEntity;
import net.troglodyte.thiccmod.entity.custom.ScooterEntity;
import net.troglodyte.thiccmod.entity.custom.TruckEntity;

public class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITY_TYPES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, ThiccMod.MODID);

    public static final RegistryObject<EntityType<DiscordKittenEntity>> DISCORD_KITTEN =
            ENTITY_TYPES.register("discord_kitten", () -> EntityType.Builder.of(DiscordKittenEntity::new, MobCategory.CREATURE).sized(1f, 2f).build("discord_kitten"));

    public static final RegistryObject<EntityType<ScooterEntity>> SCOOTER =
            ENTITY_TYPES.register("scooter", () -> EntityType.Builder.of(ScooterEntity::new, MobCategory.CREATURE).sized(1f, 2f).build("scooter"));

    public static final RegistryObject<EntityType<TruckEntity>> TRUCK =
            ENTITY_TYPES.register("truck", () -> EntityType.Builder.of(TruckEntity::new, MobCategory.CREATURE).sized(2.8f, 2.8f).build("truck"));

    public static void register(IEventBus eventBus) {
        ENTITY_TYPES.register(eventBus);
    }
}
