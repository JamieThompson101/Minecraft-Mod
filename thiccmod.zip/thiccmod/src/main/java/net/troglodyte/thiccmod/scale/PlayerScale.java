package net.troglodyte.thiccmod.scale;

import net.minecraft.nbt.CompoundTag;
import net.troglodyte.thiccmod.dementia.PlayerDementia;

public class PlayerScale {
    private float scale = 1f;

    private final float MAX_SCALE = 100f;

    private final float MIN_SCALE = 0.5f;

    public float getScale() {
        return scale;
    }

    public void addScale(float add) {
        this.scale = scale + add;
    }

    public void subScale(float sub) {
        this.scale = scale - sub;
    }

    public void setScale(float set){
        this.scale = set;
    }

    public void setMaxScale() { this.scale = MAX_SCALE; }

    public void copyFrom(PlayerScale source) {
        this.scale = source.scale;
    }

    public void saveNBTData(CompoundTag nbt) {
        nbt.putFloat("scale", scale);
    }

    public void loadNBTData(CompoundTag nbt) {
        scale = nbt.getFloat("scale");
    }
}
