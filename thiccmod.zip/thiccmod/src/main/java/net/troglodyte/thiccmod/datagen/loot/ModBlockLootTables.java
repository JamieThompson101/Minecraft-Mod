package net.troglodyte.thiccmod.datagen.loot;

import net.minecraft.data.loot.BlockLootSubProvider;
import net.minecraft.world.flag.FeatureFlagSet;
import net.minecraft.world.flag.FeatureFlags;
import net.minecraft.world.item.Item;
import net.troglodyte.thiccmod.block.ModBlocks;

import java.util.Set;

public class ModBlockLootTables extends BlockLootSubProvider {
    public ModBlockLootTables() {
        super(Set.of(), FeatureFlags.REGISTRY.allFlags());
    }
    protected ModBlockLootTables(Set<Item> pExplosionResistant, FeatureFlagSet pEnabledFeatures) {
        super(pExplosionResistant, pEnabledFeatures);
    }

    @Override
    protected void generate() {
        this.dropSelf(ModBlocks.CASE_OF_PBR_BLOCK.get());
        this.dropSelf(ModBlocks.CASE_OF_BUSCH_LIGHT.get());
        this.dropSelf(ModBlocks.CASE_OF_WINE_BLOCK.get());
        this.dropSelf(ModBlocks.REDDIT_COMPUTER.get());
    }
}
