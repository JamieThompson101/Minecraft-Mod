package net.troglodyte.thiccmod.networking.packet;

import net.minecraft.ChatFormatting;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;
import net.troglodyte.thiccmod.bac.PlayerBACProvider;
import net.troglodyte.thiccmod.client.ClientBACData;
import net.troglodyte.thiccmod.networking.ModMessages;

import java.util.function.Supplier;

public class BACC2SPacket {
    private static final String MESSAGE_LOWER_BAC = "message.thiccmod.lowerbac";
    private static final String MESSAGE_TOO_LATE_TO_LOWER_BAC = "message.thiccmod.toolate";

    public BACC2SPacket() {

    }

    public BACC2SPacket(FriendlyByteBuf buf) {

    }

    public void toBytes(FriendlyByteBuf buf) {

    }

    public boolean handle(Supplier<NetworkEvent.Context> supplier) {
        NetworkEvent.Context context = supplier.get();
        context.enqueueWork(() -> {
            // HERE WE ARE ON THE SERVER!
            ServerPlayer player = context.getSender();
            ServerLevel level = player.serverLevel();
            player.getCapability(PlayerBACProvider.PLAYER_BAC).ifPresent(bac -> {
                player.sendSystemMessage(Component.literal("Current BAC " + bac.getBAC())
                        .withStyle(ChatFormatting.RED));
                ModMessages.sendToPlayer(new BACDataSyncS2CPacket(bac.getBAC()), player);
                ClientBACData.set(bac.getBAC());
            });


        });
        return true;
    }

    private boolean isSprinting(ServerPlayer player, ServerLevel level, int size) {

        return player.isSprinting();
    }
}
