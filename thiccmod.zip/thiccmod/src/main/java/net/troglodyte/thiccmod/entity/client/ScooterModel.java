// Made with Blockbench 4.9.3
// Exported for Minecraft version 1.17 or later with Mojang mappings
// Paste this class into your mod and generate all required imports
package net.troglodyte.thiccmod.entity.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.HierarchicalModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.*;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.troglodyte.thiccmod.entity.animation.ModAnimationDefinitions;
import net.troglodyte.thiccmod.entity.custom.DiscordKittenEntity;
import net.troglodyte.thiccmod.entity.custom.ScooterEntity;

public class ScooterModel<T extends ScooterEntity> extends EntityModel<T> {
	private final ModelPart bone;
	public static final ModelLayerLocation LAYER_LOCATION = new ModelLayerLocation(new ResourceLocation("modid", "scooter"), "main");
	public ScooterModel(ModelPart root) {
		this.bone = root.getChild("bone");
	}

	public static LayerDefinition createBodyLayer() {
		MeshDefinition meshdefinition = new MeshDefinition();
		PartDefinition partdefinition = meshdefinition.getRoot();

		PartDefinition bone = partdefinition.addOrReplaceChild("bone", CubeListBuilder.create().texOffs(0, 14).addBox(-18.0F, -3.0F, -22.0F, 20.0F, 1.0F, 31.0F, new CubeDeformation(0.0F))
				.texOffs(13, 10).addBox(-9.0F, -30.0F, -20.0F, 2.0F, 27.0F, 1.0F, new CubeDeformation(0.0F))
				.texOffs(0, 4).addBox(2.0F, -4.0F, -20.0F, 2.0F, 4.0F, 4.0F, new CubeDeformation(0.0F))
				.texOffs(0, 4).addBox(-20.0F, -4.0F, -20.0F, 2.0F, 4.0F, 4.0F, new CubeDeformation(0.0F))
				.texOffs(0, 4).addBox(2.0F, -4.0F, 4.0F, 2.0F, 4.0F, 4.0F, new CubeDeformation(0.0F))
				.texOffs(0, 4).addBox(-20.0F, -4.0F, 4.0F, 2.0F, 4.0F, 4.0F, new CubeDeformation(0.0F))
				.texOffs(0, 45).addBox(-9.0F, -17.0F, 2.0F, 2.0F, 15.0F, 2.0F, new CubeDeformation(0.0F))
				.texOffs(0, 48).addBox(-15.0F, -19.0F, -4.0F, 14.0F, 2.0F, 14.0F, new CubeDeformation(0.0F))
				.texOffs(0, 0).addBox(-16.0F, -32.0F, -20.0F, 16.0F, 2.0F, 2.0F, new CubeDeformation(0.0F)), PartPose.offset(8.0F, 24.0F, 8.0F));

		return LayerDefinition.create(meshdefinition, 64, 64);
	}



	@Override
	public void renderToBuffer(PoseStack poseStack, VertexConsumer vertexConsumer, int packedLight, int packedOverlay, float red, float green, float blue, float alpha) {
		bone.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
	}


	public ModelPart root() {
		return bone;
	}

	@Override
	public void setupAnim(T t, float v, float v1, float v2, float v3, float v4) {

	}
}