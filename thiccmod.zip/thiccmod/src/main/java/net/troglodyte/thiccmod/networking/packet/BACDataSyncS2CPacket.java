package net.troglodyte.thiccmod.networking.packet;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.network.NetworkEvent;
import net.troglodyte.thiccmod.client.ClientBACData;
import net.troglodyte.thiccmod.client.ClientBloodPressureData;

import java.util.function.Supplier;

public class BACDataSyncS2CPacket {
    private final int bac;

    public BACDataSyncS2CPacket(int bp) {
        this.bac = bp;
    }

    public BACDataSyncS2CPacket(FriendlyByteBuf buf) {
        this.bac = buf.readInt();
    }

    public void toBytes(FriendlyByteBuf buf) {

        buf.writeInt(bac);
    }

    public boolean handle(Supplier<NetworkEvent.Context> supplier) {
        NetworkEvent.Context context = supplier.get();
        context.enqueueWork(() -> {
            // HERE WE ARE ON THE CLIENT!
            ClientBACData.set(bac);
        });
        return true;
    }
}
