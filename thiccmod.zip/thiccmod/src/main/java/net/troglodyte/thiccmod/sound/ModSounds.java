package net.troglodyte.thiccmod.sound;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraftforge.common.util.ForgeSoundType;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;
import net.troglodyte.thiccmod.ThiccMod;

public class ModSounds {
    public static final DeferredRegister<SoundEvent> SOUND_EVENTS =
            DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, ThiccMod.MODID);

    public static final RegistryObject<SoundEvent> COOL_SOUND = registerSoundEvent("cool_sound");
    public static final RegistryObject<SoundEvent> FAT_WALK = registerSoundEvent("fat_walk");
    public static final RegistryObject<SoundEvent> COMPUTER_BREAK_SOUND = registerSoundEvent("computer_break_sound");
    public static final RegistryObject<SoundEvent> COMPUTER_WALK_SOUND = registerSoundEvent("computer_walk_sound");
    public static final RegistryObject<SoundEvent> COMPUTER_HIT_SOUND = registerSoundEvent("computer_hit_sound");
    public static final RegistryObject<SoundEvent> COMPUTER_PLACE_SOUND = registerSoundEvent("computer_place_sound");

    public static final RegistryObject<SoundEvent> DISCORD_KITTEN_AMBIENT = registerSoundEvent("uwu");
    public static final RegistryObject<SoundEvent> DISCORD_KITTEN_AMBIENT_TWO = registerSoundEvent("uwu2");

    public static final RegistryObject<SoundEvent> DISCORD_KITTEN_NITWO = registerSoundEvent("nitwo");

    public static final RegistryObject<SoundEvent> DISCORD_KITTEN_ANGY = registerSoundEvent("rawr");

    public static final RegistryObject<SoundEvent> DISCORD_KITTEN_DEATH = registerSoundEvent("kitten_death");

    public static final RegistryObject<SoundEvent> OUT_OF_BREATH = registerSoundEvent("out_of_breath");

    public static final RegistryObject<SoundEvent> DISCORD_KITTEN_HURT = registerSoundEvent("kitten_hurt");

    public static final ForgeSoundType COMPUTER_BLOCK_SOUNDS = new ForgeSoundType(1f, 1f, COMPUTER_BREAK_SOUND, COMPUTER_WALK_SOUND, COMPUTER_PLACE_SOUND,
            COMPUTER_HIT_SOUND, COMPUTER_WALK_SOUND);
    private static RegistryObject<SoundEvent> registerSoundEvent(String name) {
        ResourceLocation id = new ResourceLocation(ThiccMod.MODID, name);
        return SOUND_EVENTS.register(name, () -> SoundEvent.createVariableRangeEvent(id));
    }
    public static void register(IEventBus eventBus) {
        SOUND_EVENTS.register(eventBus);
    }
}
