package net.troglodyte.thiccmod.networking;

import net.minecraftforge.network.PacketDistributor;
import net.troglodyte.thiccmod.ThiccMod;
import net.troglodyte.thiccmod.networking.packet.*;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkDirection;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.simple.SimpleChannel;

public class ModMessages {
    private static SimpleChannel INSTANCE;

    private static int packetId = 0;
    private static int id() {
        return packetId++;
    }

    public static void register() {
        SimpleChannel net = NetworkRegistry.ChannelBuilder
                .named(new ResourceLocation(ThiccMod.MODID, "messages"))
                .networkProtocolVersion(() -> "1.0")
                .clientAcceptedVersions(s -> true)
                .serverAcceptedVersions(s -> true)
                .simpleChannel();

        INSTANCE = net;

        net.messageBuilder(ExampleC2SPacket.class, id(), NetworkDirection.PLAY_TO_SERVER)
                .decoder(ExampleC2SPacket::new)
                .encoder(ExampleC2SPacket::toBytes)
                .consumerMainThread(ExampleC2SPacket::handle)
                .add();

        net.messageBuilder(BloodPressureC2SPacket.class, id(), NetworkDirection.PLAY_TO_SERVER)
                .decoder(BloodPressureC2SPacket::new)
                .encoder(BloodPressureC2SPacket::toBytes)
                .consumerMainThread(BloodPressureC2SPacket::handle)
                .add();

        net.messageBuilder(BloodPressureDataSyncS2CPacket.class, id(), NetworkDirection.PLAY_TO_CLIENT)
                .decoder(BloodPressureDataSyncS2CPacket::new)
                .encoder(BloodPressureDataSyncS2CPacket::toBytes)
                .consumerMainThread(BloodPressureDataSyncS2CPacket::handle)
                .add();

        net.messageBuilder(BACDataSyncS2CPacket.class, id(), NetworkDirection.PLAY_TO_CLIENT)
                .decoder(BACDataSyncS2CPacket::new)
                .encoder(BACDataSyncS2CPacket::toBytes)
                .consumerMainThread(BACDataSyncS2CPacket::handle)
                .add();

        net.messageBuilder(BACC2SPacket.class, id(), NetworkDirection.PLAY_TO_SERVER)
                .decoder(BACC2SPacket::new)
                .encoder(BACC2SPacket::toBytes)
                .consumerMainThread(BACC2SPacket::handle)
                .add();

        net.messageBuilder(ScaleC2SPacket.class, id(), NetworkDirection.PLAY_TO_SERVER)
                .decoder(ScaleC2SPacket::new)
                .encoder(ScaleC2SPacket::toBytes)
                .consumerMainThread(ScaleC2SPacket::handle)
                .add();

        net.messageBuilder(ScaleDataSyncS2CPacket.class, id(), NetworkDirection.PLAY_TO_CLIENT)
                .decoder(ScaleDataSyncS2CPacket::new)
                .encoder(ScaleDataSyncS2CPacket::toBytes)
                .consumerMainThread(ScaleDataSyncS2CPacket::handle)
                .add();
    }

    public static <MSG> void sendToServer(MSG message) {
        //INSTANCE.sendToServer(message);
    }

    public static <MSG> void sendToPlayer(MSG message, ServerPlayer player) {
        INSTANCE.send(PacketDistributor.PLAYER.with(() -> player), message);
    }
}
