package net.troglodyte.thiccmod.block.entity;

import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;
import net.troglodyte.thiccmod.ThiccMod;
import net.troglodyte.thiccmod.block.ModBlocks;

public class ModBlockEntities {
    public static DeferredRegister<BlockEntityType<?>> BLOCK_ENTITIES =
            DeferredRegister.create(ForgeRegistries.BLOCK_ENTITY_TYPES, ThiccMod.MODID);

    public static final RegistryObject<BlockEntityType<ModRedditComputerBlockEntity>> REDDIT_COMPUTER_BE =
            BLOCK_ENTITIES.register("reddit_computer_be", () ->
                    BlockEntityType.Builder.of(ModRedditComputerBlockEntity::new, ModBlocks.REDDIT_COMPUTER.get()).build(null));
    public static final RegistryObject<BlockEntityType<HelenKellerBlockEntity>> HELEN_KELLER_BE =
            BLOCK_ENTITIES.register("helen_keller_be", () ->
                    BlockEntityType.Builder.of(HelenKellerBlockEntity::new, ModBlocks.HELEN_KELLER_BLOCK.get()).build(null));

    public static void register(IEventBus eventBus){
        BLOCK_ENTITIES.register(eventBus);
    }
}
