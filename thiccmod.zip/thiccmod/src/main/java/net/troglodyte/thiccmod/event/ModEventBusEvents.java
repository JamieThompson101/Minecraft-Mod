package net.troglodyte.thiccmod.event;

import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.troglodyte.thiccmod.ThiccMod;
import net.troglodyte.thiccmod.entity.ModEntities;
import net.troglodyte.thiccmod.entity.custom.DiscordKittenEntity;
import net.troglodyte.thiccmod.entity.custom.ScooterEntity;
import net.troglodyte.thiccmod.entity.custom.TruckEntity;

@Mod.EventBusSubscriber(modid = ThiccMod.MODID, bus = Mod.EventBusSubscriber.Bus.MOD)
public class ModEventBusEvents {
    @SubscribeEvent
    public static void registerAttributes(EntityAttributeCreationEvent event) {
        event.put(ModEntities.DISCORD_KITTEN.get(), DiscordKittenEntity.createAttributes().build());
        event.put(ModEntities.SCOOTER.get(), ScooterEntity.createAttributes().build());
        event.put(ModEntities.TRUCK.get(), TruckEntity.createAttributes().build());
    }
}
