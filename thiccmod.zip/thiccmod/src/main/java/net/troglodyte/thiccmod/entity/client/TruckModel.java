package net.troglodyte.thiccmod.entity.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.*;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Entity;
import net.troglodyte.thiccmod.entity.custom.TruckEntity;

public class TruckModel<T extends TruckEntity> extends EntityModel<T> {
    private final ModelPart bone;
    public static final ModelLayerLocation LAYER_LOCATION = new ModelLayerLocation(new ResourceLocation("thiccmod", "truck"), "main");
    public TruckModel(ModelPart root) {
        this.bone = root.getChild("bone");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition meshdefinition = new MeshDefinition();
        PartDefinition partdefinition = meshdefinition.getRoot();

        PartDefinition bone = partdefinition.addOrReplaceChild("bone", CubeListBuilder.create().texOffs(0, 0).addBox(-29.0F, -3.0F, -32.0F, 43.0F, 1.0F, 81.0F, new CubeDeformation(0.0F))
                .texOffs(167, 21).addBox(-28.0F, -23.0F, -20.0F, 41.0F, 20.0F, 1.0F, new CubeDeformation(0.0F))
                .texOffs(2, 141).addBox(14.0F, -9.0F, -27.0F, 2.0F, 9.0F, 9.0F, new CubeDeformation(0.0F))
                .texOffs(0, 83).addBox(-31.0F, -9.0F, -27.0F, 2.0F, 9.0F, 9.0F, new CubeDeformation(0.0F))
                .texOffs(38, 86).addBox(14.0F, -9.0F, 34.0F, 2.0F, 9.0F, 9.0F, new CubeDeformation(0.0F))
                .texOffs(27, 114).addBox(-31.0F, -9.0F, 34.0F, 2.0F, 9.0F, 9.0F, new CubeDeformation(0.0F))
                .texOffs(84, 39).addBox(-25.0F, -14.0F, -1.0F, 35.0F, 12.0F, 2.0F, new CubeDeformation(0.0F))
                .texOffs(86, 122).addBox(-25.0F, -16.0F, -1.0F, 35.0F, 2.0F, 14.0F, new CubeDeformation(0.0F))
                .texOffs(86, 99).addBox(-30.0F, -23.0F, -33.0F, 45.0F, 21.0F, 2.0F, new CubeDeformation(0.0F))
                .texOffs(86, 82).addBox(-30.0F, -23.0F, -32.0F, 45.0F, 2.0F, 15.0F, new CubeDeformation(0.0F))
                .texOffs(1, 83).addBox(13.0F, -22.0F, -32.0F, 2.0F, 20.0F, 81.0F, new CubeDeformation(0.0F))
                .texOffs(1, 83).addBox(-30.0F, -22.0F, -32.0F, 2.0F, 20.0F, 81.0F, new CubeDeformation(0.0F))
                .texOffs(167, 0).addBox(-28.0F, -21.0F, 12.0F, 42.0F, 19.0F, 2.0F, new CubeDeformation(0.0F))
                .texOffs(86, 138).addBox(-29.0F, -22.0F, 47.0F, 43.0F, 20.0F, 2.0F, new CubeDeformation(0.0F))
                .texOffs(0, 28).addBox(-30.0F, -44.0F, -19.0F, 2.0F, 23.0F, 2.0F, new CubeDeformation(0.0F))
                .texOffs(0, 28).addBox(13.0F, -44.0F, -19.0F, 2.0F, 23.0F, 2.0F, new CubeDeformation(0.0F))
                .texOffs(0, 28).addBox(13.0F, -44.0F, 12.0F, 2.0F, 23.0F, 2.0F, new CubeDeformation(0.0F))
                .texOffs(0, 28).addBox(-30.0F, -44.0F, 12.0F, 2.0F, 23.0F, 2.0F, new CubeDeformation(0.0F))
                .texOffs(69, 191).addBox(-30.0F, -46.0F, -19.0F, 45.0F, 2.0F, 33.0F, new CubeDeformation(0.0F)), PartPose.offset(8.0F, 24.0F, 8.0F));

        PartDefinition handlebars_r1 = bone.addOrReplaceChild("handlebars_r1", CubeListBuilder.create().texOffs(0, 14).addBox(-9.0F, -9.0F, -2.0F, 16.0F, 12.0F, 2.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(-7.0F, -23.0F, -9.0F, 0.6981F, 0.0F, 0.0F));

        return LayerDefinition.create(meshdefinition, 256, 256);
    }


    @Override
    public void renderToBuffer(PoseStack poseStack, VertexConsumer vertexConsumer, int packedLight, int packedOverlay, float red, float green, float blue, float alpha) {
        bone.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
    }

    @Override
    public void setupAnim(T t, float v, float v1, float v2, float v3, float v4) {

    }
}
