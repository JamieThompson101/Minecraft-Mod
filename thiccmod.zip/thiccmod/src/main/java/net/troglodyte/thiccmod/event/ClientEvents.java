package net.troglodyte.thiccmod.event;

import net.troglodyte.thiccmod.ThiccMod;
import net.troglodyte.thiccmod.client.BACHudOverlay;
import net.troglodyte.thiccmod.client.DementiaHudOverlay;
import net.troglodyte.thiccmod.networking.ModMessages;
import net.troglodyte.thiccmod.networking.packet.BACC2SPacket;
import net.troglodyte.thiccmod.networking.packet.BloodPressureC2SPacket;
import net.troglodyte.thiccmod.util.KeyBinding;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.InputEvent;
import net.minecraftforge.client.event.RegisterGuiOverlaysEvent;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

public class ClientEvents {
    @Mod.EventBusSubscriber(modid = ThiccMod.MODID, value = Dist.CLIENT)
    public static class ClientForgeEvents {
        @SubscribeEvent
        public static void onKeyInput(InputEvent.Key event) {
            if(KeyBinding.DRINKING_KEY.consumeClick()) {
                ModMessages.sendToServer(new BACC2SPacket());
            }
        }
    }

    @Mod.EventBusSubscriber(modid = ThiccMod.MODID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.MOD)
    public static class ClientModBusEvents {
        @SubscribeEvent
        public static void onKeyRegister(RegisterKeyMappingsEvent event) {
            event.register(KeyBinding.DRINKING_KEY);
        }

        @SubscribeEvent
        public static void registerGuiOverlays(RegisterGuiOverlaysEvent event) {
            //event.registerAboveAll("bac", BACHudOverlay.HUD_BAC);
           // event.registerAboveAll("bloodpressure", BloodPressureHudOverlay.HUD_BLOODPRESSURE);
            //event.registerAboveAll("dementia", DementiaHudOverlay.HUD_DEMENTIA);
        }
    }
}