package net.troglodyte.thiccmod.networking.packet;

import net.minecraft.ChatFormatting;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;
import net.troglodyte.thiccmod.client.ClientScaleData;
import net.troglodyte.thiccmod.networking.ModMessages;
import net.troglodyte.thiccmod.scale.PlayerScaleProvider;

import java.util.function.Supplier;

public class ScaleC2SPacket {

    private static final String MESSAGE_LOWER_SCALE = "message.thiccmod.lowerscale";
    private static final String MESSAGE_TOO_LATE_TO_LOWER_SCALE = "message.thiccmod.scaletoolate";

    public ScaleC2SPacket() {

    }

    public ScaleC2SPacket(FriendlyByteBuf buf) {

    }

    public void toBytes(FriendlyByteBuf buf) {

    }

    public boolean handle(Supplier<NetworkEvent.Context> supplier) {
        NetworkEvent.Context context = supplier.get();
        context.enqueueWork(() -> {
            // HERE WE ARE ON THE SERVER!
            ServerPlayer player = context.getSender();
            ServerLevel level = player.serverLevel();
            player.getCapability(PlayerScaleProvider.PLAYER_SCALE).ifPresent(scale -> {
                player.sendSystemMessage(Component.literal("Current Scale " + scale.getScale())
                        .withStyle(ChatFormatting.RED));
                ModMessages.sendToPlayer(new ScaleDataSyncS2CPacket(scale.getScale()), player);
                ClientScaleData.set(scale.getScale());
            });


        });
        return true;
    }

    private boolean isSprinting(ServerPlayer player, ServerLevel level, int size) {

        return player.isSprinting();
    }
}
