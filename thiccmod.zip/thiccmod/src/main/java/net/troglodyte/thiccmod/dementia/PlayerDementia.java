package net.troglodyte.thiccmod.dementia;

import net.minecraft.nbt.CompoundTag;

public class PlayerDementia {

    private int dementia;

    private final int MAX_DEMENTIA = 200;

    private final int MIN_DEMENTIA = 0;

    public int getDementia() {
        return dementia;
    }

    public void addDementia(int add) {
        this.dementia = Math.min(dementia + add, MAX_DEMENTIA);
    }

    public void subDementia(int sub) {
        this.dementia = Math.max(dementia - sub, MIN_DEMENTIA);
    }

    public void setMaxDementia() { this.dementia = 200; }

    public void copyFrom(PlayerDementia source) {
        this.dementia = source.dementia;
    }

    public void saveNBTData(CompoundTag nbt) {
        nbt.putInt("dementia", dementia);
    }

    public void loadNBTData(CompoundTag nbt) {
        dementia = nbt.getInt("dementia");
    }


}
