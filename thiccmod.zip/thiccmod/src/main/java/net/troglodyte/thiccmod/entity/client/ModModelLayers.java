package net.troglodyte.thiccmod.entity.client;

import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.resources.ResourceLocation;
import net.troglodyte.thiccmod.ThiccMod;

public class ModModelLayers {
    public static final ModelLayerLocation DISCORD_KITTEN_LAYER = new ModelLayerLocation(
            new ResourceLocation(ThiccMod.MODID, "discord_kitten_layer"), "main");
    public static final ModelLayerLocation SCOOTER_LAYER = new ModelLayerLocation(
            new ResourceLocation(ThiccMod.MODID, "scooter_layer"), "main");

    public static final ModelLayerLocation TRUCK_LAYER = new ModelLayerLocation(
            new ResourceLocation(ThiccMod.MODID, "truck_layer"), "main");
}
