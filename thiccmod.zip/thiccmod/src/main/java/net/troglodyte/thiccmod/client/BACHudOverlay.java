package net.troglodyte.thiccmod.client;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.logging.LogUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.client.gui.overlay.IGuiOverlay;
import net.troglodyte.thiccmod.ThiccMod;
import org.slf4j.Logger;

public class BACHudOverlay {
    private static final ResourceLocation FILLED_BAC = new ResourceLocation(ThiccMod.MODID,
            "textures/blood_pressure/filled_blood_pressure.png");
    private static final ResourceLocation EMPTY_BAC = new ResourceLocation(ThiccMod.MODID,
            "textures/blood_pressure/empty_blood_pressure.png");

    private static final Logger LOGGER = LogUtils.getLogger();


    protected static Minecraft mc = Minecraft.getInstance();
    protected static MultiBufferSource.BufferSource bufferSource = mc.renderBuffers().bufferSource();



    static GuiGraphics guiGraphics = new GuiGraphics(mc, bufferSource);

    public static final IGuiOverlay HUD_BAC = ((gui, poseStack, partialTick, width, height) -> {
        int x = width / 2;
        int y = height;

        RenderSystem.setShader(GameRenderer::getPositionTexShader);
        RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
        RenderSystem.setShaderTexture(0, EMPTY_BAC);


        for(int i = 0; i < 40; i++) {
            guiGraphics.blit(EMPTY_BAC,x - 90 + (i * 4), y - 52,0,0,6,12,
                    6,12);
        }
        RenderSystem.setShaderTexture(0, FILLED_BAC);
        for(int i = 0; i < 40; i++) {
            if(ClientBACData.getPlayerBAC() > i) {
                guiGraphics.blit(FILLED_BAC,x - 90 + (i * 4),y - 52,0,0,6,12,
                        6,12);
            } else {
                break;
            }
        }

    });
}
