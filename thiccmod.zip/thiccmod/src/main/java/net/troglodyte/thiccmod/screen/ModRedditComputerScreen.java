package net.troglodyte.thiccmod.screen;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Inventory;
import net.troglodyte.thiccmod.ThiccMod;

import java.util.Random;

public class ModRedditComputerScreen extends AbstractContainerScreen<ModRedditComputerMenu> {
    private ResourceLocation texture  =
            new ResourceLocation(ThiccMod.MODID, getTexturePicked());
    public ModRedditComputerScreen(ModRedditComputerMenu pMenu, Inventory pPlayerInventory, Component pTitle) {
        super(pMenu, pPlayerInventory, pTitle);
    }

    private String getTexturePicked () {
        Random rand = new Random();
        int maxPics = 6;
        int picked = rand.nextInt(maxPics);
        if (picked == 0){
            return "textures/gui/reddit_computer_0.png";
        }
        else if (picked == 1){
            return "textures/gui/reddit_computer_1.png";
        }
        else if (picked == 2){
            return "textures/gui/reddit_computer_2.png";
        }
        else if (picked == 3){
            return "textures/gui/reddit_computer_3.png";
        }
        else if (picked == 4){
            return "textures/gui/reddit_computer_4.png";
        }
        else if (picked == 5){
            return "textures/gui/reddit_computer_5.png";
        }
        return "textures/gui/reddit_computer.png";
    }

    private void randomizeTexture () {
        String randomLocation = getTexturePicked();
        texture = new ResourceLocation(ThiccMod.MODID, randomLocation);
    }

    @Override
    protected void init() {
        super.init();
        this.inventoryLabelY = 10000;
        this.titleLabelY = 10000;
        this.inventoryLabelX = 10000;
    }

    private void renderProgressArrow(GuiGraphics guiGraphics, int x, int y) {
        if(menu.isCrafting()) {
            guiGraphics.blit(texture, x + 85, y + 30, 176, 0, 8, menu.getScaledProgress());
        }
    }

    @Override
    protected void renderBg(GuiGraphics guiGraphics, float pPartialTick, int pMouseX, int pMouseY) {
        RenderSystem.setShader(GameRenderer::getPositionTexShader);
        RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
        RenderSystem.setShaderTexture(0, texture);
        int x = (width - imageWidth) / 2;
        int y = (height - imageHeight) / 2;

        guiGraphics.blit(texture, x, y, 0, 0, imageWidth, imageHeight);

    }
}
