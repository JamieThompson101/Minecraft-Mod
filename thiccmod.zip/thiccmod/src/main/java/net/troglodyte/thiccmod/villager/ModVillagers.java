package net.troglodyte.thiccmod.villager;

import com.google.common.collect.ImmutableSet;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.entity.ai.village.poi.PoiType;
import net.minecraft.world.entity.npc.VillagerProfession;
import net.minecraft.world.level.block.Blocks;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;
import net.troglodyte.thiccmod.ThiccMod;
import net.troglodyte.thiccmod.block.ModBlocks;

public class ModVillagers {
    public static final DeferredRegister<PoiType> POI_TYPES =
            DeferredRegister.create(ForgeRegistries.POI_TYPES, ThiccMod.MODID);
    public static final DeferredRegister<VillagerProfession> VILLAGER_PROFESSIONS =
            DeferredRegister.create(ForgeRegistries.VILLAGER_PROFESSIONS, ThiccMod.MODID);

    public static final RegistryObject<PoiType> COMPUTER_POI = POI_TYPES.register("computer_poi",
            () -> new PoiType(ImmutableSet.copyOf(ModBlocks.REDDIT_COMPUTER.get().getStateDefinition().getPossibleStates()),
                    1, 1));
    public static final RegistryObject<PoiType> WAFFLE_POI = POI_TYPES.register("waffle_poi",
            () -> new PoiType(ImmutableSet.copyOf(Blocks.POLISHED_DIORITE.getStateDefinition().getPossibleStates()),
                    1, 1));
    public static final RegistryObject<PoiType> WALMART_POI = POI_TYPES.register("walmart_poi",
            () -> new PoiType(ImmutableSet.copyOf(Blocks.CHISELED_DEEPSLATE.getStateDefinition().getPossibleStates()),
                    1, 1));
    public static final RegistryObject<PoiType> MCDONALDS_POI = POI_TYPES.register("mcdonalds_poi",
            () -> new PoiType(ImmutableSet.copyOf(Blocks.CHISELED_QUARTZ_BLOCK.getStateDefinition().getPossibleStates()),
                    1, 1));
    public static final RegistryObject<PoiType> ARBYS_POI = POI_TYPES.register("arbys_poi",
            () -> new PoiType(ImmutableSet.copyOf(Blocks.CHISELED_NETHER_BRICKS.getStateDefinition().getPossibleStates()),
                    1, 1));
    public static final RegistryObject<PoiType> CHICFILA_POI = POI_TYPES.register("chicfila_poi",
            () -> new PoiType(ImmutableSet.copyOf(Blocks.CHISELED_POLISHED_BLACKSTONE.getStateDefinition().getPossibleStates()),
                    1, 1));
    public static final RegistryObject<PoiType> LIQUOR_POI = POI_TYPES.register("liquor_poi",
            () -> new PoiType(ImmutableSet.copyOf(ModBlocks.CASE_OF_WINE_BLOCK.get().getStateDefinition().getPossibleStates()),
                    1, 1));

    public static final RegistryObject<VillagerProfession> COMPUTER_MASTER =
            VILLAGER_PROFESSIONS.register("computerworker", () -> new VillagerProfession("computerworker",
                    holder -> holder.get() == COMPUTER_POI.get(), holder -> holder.get() == COMPUTER_POI.get(),
                    ImmutableSet.of(), ImmutableSet.of(), SoundEvents.VILLAGER_WORK_ARMORER));

    public static final RegistryObject<VillagerProfession> WAFFLE_MASTER =
            VILLAGER_PROFESSIONS.register("wafflehouseworker", () -> new VillagerProfession("wafflehouseworker",
                    holder -> holder.get() == WAFFLE_POI.get(), holder -> holder.get() == WAFFLE_POI.get(),
                    ImmutableSet.of(), ImmutableSet.of(), SoundEvents.VILLAGER_WORK_FARMER));

    public static final RegistryObject<VillagerProfession> MCDONALDS_MASTER =
            VILLAGER_PROFESSIONS.register("mcdonaldsworker", () -> new VillagerProfession("mcdonaldsworker",
                    holder -> holder.get() == MCDONALDS_POI.get(), holder -> holder.get() == MCDONALDS_POI.get(),
                    ImmutableSet.of(), ImmutableSet.of(), SoundEvents.VILLAGER_WORK_BUTCHER));
    public static final RegistryObject<VillagerProfession> ARBYS_MASTER =
            VILLAGER_PROFESSIONS.register("arbysworker", () -> new VillagerProfession("arbysworker",
                    holder -> holder.get() == ARBYS_POI.get(), holder -> holder.get() == ARBYS_POI.get(),
                    ImmutableSet.of(), ImmutableSet.of(), SoundEvents.VILLAGER_WORK_FARMER));
    public static final RegistryObject<VillagerProfession> CHICFILA_MASTER =
            VILLAGER_PROFESSIONS.register("chicfilaworker", () -> new VillagerProfession("chicfilaworker",
                    holder -> holder.get() == CHICFILA_POI.get(), holder -> holder.get() == CHICFILA_POI.get(),
                    ImmutableSet.of(), ImmutableSet.of(), SoundEvents.VILLAGER_WORK_LEATHERWORKER));

    public static final RegistryObject<VillagerProfession> WALMART_MASTER =
            VILLAGER_PROFESSIONS.register("walmartworker", () -> new VillagerProfession("walmartworker",
                    holder -> holder.get() == WALMART_POI.get(), holder -> holder.get() == WALMART_POI.get(),
                    ImmutableSet.of(), ImmutableSet.of(), SoundEvents.VILLAGER_WORK_ARMORER));

    public static final RegistryObject<VillagerProfession> LIQUOR_MASTER =
            VILLAGER_PROFESSIONS.register("liquorstoreworker", () -> new VillagerProfession("liquorstoreworker",
                    holder -> holder.get() == LIQUOR_POI.get(), holder -> holder.get() == LIQUOR_POI.get(),
                    ImmutableSet.of(), ImmutableSet.of(), SoundEvents.VILLAGER_WORK_CLERIC));

    public static void register(IEventBus eventBus) {
        POI_TYPES.register(eventBus);
        VILLAGER_PROFESSIONS.register(eventBus);
    }
}
