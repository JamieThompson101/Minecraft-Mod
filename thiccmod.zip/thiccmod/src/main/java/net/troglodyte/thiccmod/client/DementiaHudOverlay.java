package net.troglodyte.thiccmod.client;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.client.gui.overlay.IGuiOverlay;
import net.troglodyte.thiccmod.ThiccMod;

public class DementiaHudOverlay {

    private static final ResourceLocation FILLED_DEMENTIA = new ResourceLocation(ThiccMod.MODID,
            "textures/blood_pressure/filled_dementia.png");
    private static final ResourceLocation EMPTY_DEMENTIA = new ResourceLocation(ThiccMod.MODID,
            "textures/blood_pressure/empty_dementia.png");


    //protected Minecraft mc = Minecraft.getInstance();
    //protected MultiBufferSource.BufferSource bufferSource = new MultiBufferSource.BufferSource();
    //protected static GameConfig gameConfig = new GameConfig();



    // static GuiGraphics guiGraphics = new GuiGraphics(new Minecraft(gameConfig), );

    public static final IGuiOverlay HUD_DEMENTIA = ((gui, poseStack, partialTick, width, height) -> {
        int x = width / 2;
        int y = height;

        RenderSystem.setShader(GameRenderer::getPositionTexShader);
        RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
        RenderSystem.setShaderTexture(0, EMPTY_DEMENTIA);

        RenderSystem.setShaderTexture(0, FILLED_DEMENTIA);

    });
}
