package net.troglodyte.thiccmod.item;

import net.minecraft.world.item.Item;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;
import net.troglodyte.thiccmod.ThiccMod;
import net.troglodyte.thiccmod.entity.ModEntities;

public class ModItems {
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, ThiccMod.MODID);

    public static final RegistryObject<Item> DORITOS = ITEMS.register("doritos", () -> new Item(new Item.Properties().food(ModFoods.DORITOS)));
    public static final RegistryObject<Item> BORGAR = ITEMS.register("borgar", () -> new Item(new Item.Properties().food(ModFoods.BORGAR)));
    public static final RegistryObject<Item> MOUNTAINDEW = ITEMS.register("mountaindew", () -> new Item(new Item.Properties().food(ModFoods.MOUNTAINDEW)));

    public static final RegistryObject<Item> FRIES = ITEMS.register("fries", () -> new Item(new Item.Properties().food(ModFoods.FRIES)));
    public static final RegistryObject<Item> NUGGIES = ITEMS.register("nuggies", () -> new Item(new Item.Properties().food(ModFoods.NUGGIES)));
    public static final RegistryObject<Item> BBQSAUCE = ITEMS.register("bbqsauce", () -> new Item(new Item.Properties().food(ModFoods.BBQSAUCE)));
    public static final RegistryObject<Item> BIGMAC = ITEMS.register("bigmac", () -> new Item(new Item.Properties().food(ModFoods.BIGMAC)));
    public static final RegistryObject<Item> ARBYSROASTBEEF = ITEMS.register("arbysroastbeef", () -> new Item(new Item.Properties().food(ModFoods.ARBYSROASTBEEF)));
    public static final RegistryObject<Item> CHICKENSANDWICH = ITEMS.register("chickensandwich", () -> new Item(new Item.Properties().food(ModFoods.CHICKENSANDWICH)));
    public static final RegistryObject<Item> SPICYRAMEN = ITEMS.register("spicyramen", () -> new Item(new Item.Properties().food(ModFoods.SPICYRAMEN)));
    public static final RegistryObject<Item> SPICYTAKIS = ITEMS.register("spicytakis", () -> new Item(new Item.Properties().food(ModFoods.SPICYTAKIS)));
    public static final RegistryObject<Item> BUSCH_LITE = ITEMS.register("buschlite", () -> new BuschLiteItem(new Item.Properties().food(ModFoods.BUSCH_LITE)));
    public static final RegistryObject<Item> BOURBON = ITEMS.register("bourbon", () -> new BourbonItem(new Item.Properties().food(ModFoods.BOURBON)));
    public static final RegistryObject<Item> WINE = ITEMS.register("wine", () -> new BourbonItem(new Item.Properties().food(ModFoods.WINE)));
    public static final RegistryObject<Item> PBR = ITEMS.register("pbr", () -> new BourbonItem(new Item.Properties().food(ModFoods.PBR)));
    public static final RegistryObject<Item> SCOTCH = ITEMS.register("scotch", () -> new BourbonItem(new Item.Properties().food(ModFoods.SCOTCH)));
    public static final RegistryObject<Item> MOONSHINE = ITEMS.register("moonshine", () -> new BourbonItem(new Item.Properties().food(ModFoods.MOONSHINE)));
    public static final RegistryObject<Item> NATTY_DADDY = ITEMS.register("nattydaddy", () -> new BourbonItem(new Item.Properties().food(ModFoods.NATTY_DADDY)));
    public static final RegistryObject<Item> FOURLOKO = ITEMS.register("fourloko", () -> new BourbonItem(new Item.Properties().food(ModFoods.FOURLOKO)));

    public static final RegistryObject<Item> ANTIDEPRESSANT = ITEMS.register("antidepressant",  () -> new Item(new Item.Properties().food(ModFoods.ANTIDEPRESSANT)));

    public static final RegistryObject<Item> DISCORD_NITRO = ITEMS.register("discord_nitro", () -> new Item(new Item.Properties().stacksTo(64)));

    public static final RegistryObject<Item> WAFFLE = ITEMS.register("waffle", () -> new Item(new Item.Properties().food(ModFoods.WAFFLE)));

    public static final RegistryObject<Item> POOP = ITEMS.register("poop", () -> new Item(new Item.Properties().food(ModFoods.POOP)));

    public static final RegistryObject<Item> DISCORD_KITTEN_SPAWN_EGG = ITEMS.register("discord_kitten_spawn_egg", () -> new ForgeSpawnEggItem(ModEntities.DISCORD_KITTEN, 0xf7c5ca, 0xec737e, new Item.Properties()));
    public static final RegistryObject<Item> SCOOTER_SPAWN_EGG = ITEMS.register("scooter_spawn_egg", () -> new ForgeSpawnEggItem(ModEntities.SCOOTER, 0x362312, 0xaaaaaa, new Item.Properties()));

    public static final RegistryObject<Item> TRUCK_SPAWN_EGG = ITEMS.register("truck_spawn_egg", () -> new ForgeSpawnEggItem(ModEntities.TRUCK, 0xb40a1a, 0x9a080f, new Item.Properties()));

    public static void register(IEventBus eventBus){
        ITEMS.register(eventBus);
    }
}
